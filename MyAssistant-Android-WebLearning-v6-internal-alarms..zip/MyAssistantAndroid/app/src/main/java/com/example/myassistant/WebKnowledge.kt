package com.example.myassistant

import android.text.Html
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * تعلم آمن من صفحات عامة: يجلب النص فقط، يحذف script/style، ولا ينفذ JavaScript أو ملفات.
 * لا يتجاوز تسجيل الدخول أو الحجب أو paywall، ويحترم حد الحجم والمهلة.
 */
object WebKnowledge {
    private const val MAX_BYTES = 1_000_000

    fun learn(urlString: String, prefs: Prefs): String {
        require(urlString.startsWith("https://")) { "لا أقبل إلا روابط HTTPS العامة." }
        val conn = URL(urlString).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 10000
            conn.instanceFollowRedirects = true
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "MyAssistant-Android/1.0 (user initiated)")
            val type = conn.contentType.orEmpty().lowercase()
            if (type.isNotEmpty() && !type.contains("text/html") && !type.contains("text/plain") && !type.contains("xhtml")) {
                throw IllegalArgumentException("الرابط ليس صفحة نصية عامة")
            }
            val text = conn.inputStream.use { input ->
                val bytes = input.readNBytes(MAX_BYTES + 1)
                if (bytes.size > MAX_BYTES) throw IllegalArgumentException("الصفحة أكبر من الحد المسموح")
                bytes.toString(Charsets.UTF_8)
            }
            val title = Regex("(?is)<title[^>]*>(.*?)</title>").find(text)?.groupValues?.get(1)
                ?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
            val clean = text
                .replace(Regex("(?is)<(script|style|noscript|iframe)[^>]*>.*?</\\1>"), " ")
                .replace(Regex("(?is)<[^>]+>"), " ")
                .let { Html.fromHtml(it, Html.FROM_HTML_MODE_LEGACY).toString() }
                .replace(Regex("\\s+"), " ")
                .trim()
            if (clean.length < 40) throw IllegalArgumentException("لم أجد نصًا مقروءًا في الصفحة")
            val snippet = clean.take(1500)
            val record = JSONObject()
                .put("title", title.ifBlank { urlString })
                .put("url", urlString)
                .put("text", snippet)
                .toString()
            prefs.addWebKnowledge(record)
            return "تعلمت من الصفحة «${title.ifBlank { "بدون عنوان" }}» وحفظت نصًا مختصرًا محليًا."
        } finally {
            conn.disconnect()
        }
    }
}
