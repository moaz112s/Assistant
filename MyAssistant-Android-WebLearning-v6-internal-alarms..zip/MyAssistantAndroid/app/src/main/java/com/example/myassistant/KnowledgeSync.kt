package com.example.myassistant

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * يحدّث مرادفات الأوامر من JSON اختياري.
 * الحزمة بيانات فقط: phrase -> command معروف مسبقًا، ولا يمكنها تشغيل كود أو APK.
 */
object KnowledgeSync {
    private val allowed = setOf(
        "الوقت", "التاريخ", "البطارية", "الرام", "المساحة", "حالة الجهاز", "وين انا",
        "مساعدة", "الملاحظات", "الطقس", "افتح واتساب", "افتح كروم"
    )

    fun sync(urlString: String, prefs: Prefs): Int {
        require(urlString.startsWith("https://")) { "مصدر المعرفة يجب أن يبدأ بـ HTTPS" }
        val conn = URL(urlString).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/json")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val commands = JSONObject(body).optJSONArray("commands") ?: return 0
            val learned = prefs.autoLearned()
            val autoCommands = prefs.autoCommands()
            var added = 0
            for (i in 0 until commands.length()) {
                val item = commands.optJSONObject(i) ?: continue
                val phrase = Arabic.normalize(item.optString("phrase"))
                val command = Arabic.numberWords(Arabic.normalize(item.optString("command")))
                if (phrase.length < 2 || command !in allowed) continue
                learned[phrase] = command
                autoCommands[phrase] = command to true
                added++
            }
            prefs.saveAutoLearned(learned)
            prefs.saveAutoCommands(autoCommands)
            return added
        } finally {
            conn.disconnect()
        }
    }
}
