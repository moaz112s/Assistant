package com.example.myassistant

import java.util.Locale

/** أدوات معالجة النص العربي. */
object Arabic {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u0640]")

    /** تحويل الأرقام العربية-الهندية إلى أرقام لاتينية. */
    fun toAsciiDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
                in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
                '\u066B' -> sb.append('.')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** تصحيح أخطاء صوتية وكتابية شائعة قبل مطابقة الأوامر. */
    private fun correctCommonErrors(t: String): String {
        var out = t
        val corrections = listOf(
            "وتساب" to "واتساب", "وتس اب" to "واتس اب", "واتس آب" to "واتساب",
            "واتسأب" to "واتساب", "واتس ابب" to "واتس اب", "يوتيوبب" to "يوتيوب",
            "تلجرام" to "تلغرام", "تليغرام" to "تلغرام", "انستقرام" to "انستغرام",
            "انستجرام" to "انستغرام", "فيس بوك" to "فيسبوك", "جوجل كروم" to "كروم"
        )
        for ((bad, good) in corrections) out = out.replace(bad, good)
        return out
    }

    /** نص خفيف: بلا تشكيل وبأرقام لاتينية، ويحافظ على الحروف كما هي. */
    fun light(s: String): String {
        var t = diacritics.replace(s, "")
        t = toAsciiDigits(t)
        t = correctCommonErrors(t)
        t = t.replace(Regex("[؟?!،؛]"), " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * يحول الأرقام العربية المكتوبة بالكلمات إلى أرقام، مثل «خمسة وعشرون» إلى 25.
     * يستخدمه موجه الأوامر فقط حتى لا يغير نصوص الملاحظات المحفوظة.
     */
    fun numberWords(s: String): String {
        val n = normalize(s)
        val units = mapOf(
            "صفر" to 0, "واحد" to 1, "واحده" to 1, "اثنان" to 2, "اثنين" to 2,
            "اثنتان" to 2, "اثنتين" to 2, "ثلاثه" to 3, "ثلاث" to 3, "اربعه" to 4,
            "اربع" to 4, "خمسه" to 5, "خمس" to 5, "سته" to 6, "ست" to 6,
            "سبعه" to 7, "سبع" to 7, "ثمانيه" to 8, "ثمان" to 8, "تسعه" to 9,
            "تسع" to 9, "عشره" to 10, "عشر" to 10
        )
        val tens = mapOf("عشرون" to 20, "ثلاثون" to 30, "اربعون" to 40, "خمسون" to 50, "ستون" to 60, "سبعون" to 70, "ثمانون" to 80, "تسعون" to 90)
        val rawTokens = n.split(" ").filter { it.isNotEmpty() }
        val tokens = mutableListOf<String>()
        for (token in rawTokens) {
            val suffix = token.removePrefix("و")
            if (token.startsWith("و") && (units.containsKey(suffix) || tens.containsKey(suffix))) {
                tokens.add("و")
                tokens.add(suffix)
            } else {
                tokens.add(token)
            }
        }
        val out = mutableListOf<String>()
        var i = 0
        while (i < tokens.size) {
            if (i + 2 < tokens.size && units[tokens[i]] != null && tokens[i + 1] == "و" && tens[tokens[i + 2]] != null) {
                out.add((units[tokens[i]]!! + tens[tokens[i + 2]]!!).toString())
                i += 3
            } else if (i + 1 < tokens.size && tokens[i] == "مائه" && units[tokens[i + 1]] != null) {
                out.add((100 + units[tokens[i + 1]]!!).toString())
                i += 2
            } else if (units[tokens[i]] != null) {
                out.add(units[tokens[i]]!!.toString())
                i++
            } else if (tens[tokens[i]] != null) {
                out.add(tens[tokens[i]]!!.toString())
                i++
            } else {
                out.add(tokens[i])
                i++
            }
        }
        return out.joinToString(" ")
    }

    /** تطبيع كامل للمطابقة: توحيد الألف والتاء المربوطة والألف المقصورة. */
    fun normalize(s: String): String {
        var t = light(s).lowercase(Locale.ROOT)
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        t = t.replace('ة', 'ه').replace('ى', 'ي')
        return t.trim()
    }

    private fun wakeNames(customName: String): List<String> =
        listOf(customName, "مساعد", "مساعدي").map(::normalize).filter { it.isNotEmpty() }.distinct()

    fun stripWake(t: String, customName: String = "مساعد"): String {
        val n = normalize(t)
        val prefix = wakeNames(customName).flatMap { listOf("يا $it", it) }
            .firstOrNull { n == it || n.startsWith("$it ") }
        return if (prefix == null) n else n.removePrefix(prefix).trim()
    }

    fun wakeRest(text: String, customName: String = "مساعد"): String? {
        val n = normalize(text)
        val prefix = wakeNames(customName).flatMap { listOf("يا $it" to it, it to it) }
            .firstOrNull { (candidate, _) -> n == candidate || n.startsWith("$candidate ") }
            ?: return null
        return n.removePrefix(prefix.first).trim()
    }
}
