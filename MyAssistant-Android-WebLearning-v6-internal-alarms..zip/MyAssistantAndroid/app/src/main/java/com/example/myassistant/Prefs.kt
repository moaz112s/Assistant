package com.example.myassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** تخزين محلي بسيط على الهاتف فقط (لا يُرسل لأي مكان). */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("assistant_prefs", Context.MODE_PRIVATE)

    var firstRunDone: Boolean
        get() = sp.getBoolean("first_run_done", false)
        set(v) { sp.edit().putBoolean("first_run_done", v).apply() }

    /** الاسم الذي ينادي به المستخدم المساعد، مثل «مساعد» أو «سيري». */
    var assistantName: String
        get() = sp.getString("assistant_name", "مساعد") ?: "مساعد"
        set(v) { sp.edit().putString("assistant_name", v.trim()).apply() }

    var ttsOn: Boolean
        get() = sp.getBoolean("tts_on", true)
        set(v) { sp.edit().putBoolean("tts_on", v).apply() }

    var speechLang: String
        get() = sp.getString("speech_lang", "ar-EG") ?: "ar-EG"
        set(v) { sp.edit().putString("speech_lang", v).apply() }

    var autoSendSos: Boolean
        get() = sp.getBoolean("auto_send_sos", false)
        set(v) { sp.edit().putBoolean("auto_send_sos", v).apply() }

    var emergencyContacts: List<String>
        get() = (sp.getString("emergency_contacts", "") ?: "")
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("emergency_contacts", v.joinToString(",")).apply() }

    var handsFree: Boolean
        get() = sp.getBoolean("hands_free", false)
        set(v) { sp.edit().putBoolean("hands_free", v).apply() }

    /** 0 صارمة، 1 متوسطة، 2 متساهلة. */
    var wakeSensitivity: Int
        get() = sp.getInt("wake_sensitivity", 1)
        set(v) { sp.edit().putInt("wake_sensitivity", v).apply() }

    /** سرعة الاستجابة: 0 سريع، 1 متوازن، 2 دقيق. */
    var responseSpeed: Int
        get() = sp.getInt("response_speed", 1)
        set(v) { sp.edit().putInt("response_speed", v.coerceIn(0, 2)).apply() }

    /** عند التفعيل تظهر نتيجة كل محاولة تعرّف (للضبط). */
    var wakeDebug: Boolean
        get() = sp.getBoolean("wake_debug", false)
        set(v) { sp.edit().putBoolean("wake_debug", v).apply() }

    /** 0 = الاستماع عبر خدمة Google، 1 = كشف محلي بصوتك. */
    var wakeMode: Int
        get() = sp.getInt("wake_mode", 0)
        set(v) { sp.edit().putInt("wake_mode", v).apply() }

    /** السماح بإرسال الصوت للإنترنت أثناء الاستماع عبر Google. */
    var allowOnline: Boolean
        get() = sp.getBoolean("allow_online", false)
        set(v) { sp.edit().putBoolean("allow_online", v).apply() }

    var googleConsent: Boolean
        get() = sp.getBoolean("google_consent", false)
        set(v) { sp.edit().putBoolean("google_consent", v).apply() }

    /** رابط JSON اختياري لحزمة أوامر موثوقة يحددها المستخدم. لا ينفذ التطبيق كودًا منه. */
    var knowledgeUrl: String
        get() = sp.getString("knowledge_url", "") ?: ""
        set(v) { sp.edit().putString("knowledge_url", v.trim()).apply() }

    fun notes(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(sp.getString("notes", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveNotes(list: List<String>) {
        val arr = JSONArray()
        for (s in list) arr.put(s)
        sp.edit().putString("notes", arr.toString()).apply()
    }

    /** العبارات المتعلَّمة: عبارة مطبَّعة -> أمر. */
    fun learned(): MutableMap<String, String> {
        val out = mutableMapOf<String, String>()
        try {
            val obj = JSONObject(sp.getString("learned", "{}") ?: "{}")
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                out[k] = obj.getString(k)
            }
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveLearned(map: Map<String, String>) {
        val obj = JSONObject()
        for ((k, v) in map) obj.put(k, v)
        sp.edit().putString("learned", obj.toString()).apply()
    }

    /** ذاكرة حقائق يضيفها المستخدم صراحةً، وليست سجلًا سريًا للمحادثات. */
    fun facts(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(sp.getString("facts", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveFacts(list: List<String>) {
        val arr = JSONArray()
        for (s in list.distinct().takeLast(100)) arr.put(s)
        sp.edit().putString("facts", arr.toString()).apply()
    }

    /** صيغ تعلمها الوكيل تلقائيًا بعد تكرار واضح، عبارة مطبعة -> أمر آمن معروف. */
    fun autoLearned(): MutableMap<String, String> {
        val out = mutableMapOf<String, String>()
        try {
            val obj = JSONObject(sp.getString("auto_learned", "{}") ?: "{}")
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                out[k] = obj.getString(k)
            }
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveAutoLearned(map: Map<String, String>) {
        val obj = JSONObject()
        for ((k, v) in map.toList().takeLast(100)) obj.put(k, v)
        sp.edit().putString("auto_learned", obj.toString()).apply()
    }

    fun recordExperience(phrase: String): Int {
        val key = "experience_${phrase.hashCode()}"
        val count = sp.getInt(key, 0) + 1
        sp.edit().putInt(key, count).apply()
        return count
    }

    /** أوامر أنشأها التعلم التلقائي: عبارة -> أمر معروف مسبقًا. */
    fun autoCommands(): MutableMap<String, Pair<String, Boolean>> {
        val out = mutableMapOf<String, Pair<String, Boolean>>()
        try {
            val obj = JSONObject(sp.getString("auto_commands", "{}") ?: "{}")
            val keys = obj.keys()
            while (keys.hasNext()) {
                val phrase = keys.next()
                val item = obj.getJSONObject(phrase)
                out[phrase] = item.optString("command") to item.optBoolean("confirm", true)
            }
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveAutoCommands(map: Map<String, Pair<String, Boolean>>) {
        val obj = JSONObject()
        for ((phrase, value) in map.toList().takeLast(100)) {
            obj.put(phrase, JSONObject().put("command", value.first).put("confirm", value.second))
        }
        sp.edit().putString("auto_commands", obj.toString()).apply()
    }

    fun webKnowledge(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(sp.getString("web_knowledge", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun addWebKnowledge(record: String) {
        val list = webKnowledge()
        list.add(record)
        val arr = JSONArray()
        for (s in list.takeLast(50)) arr.put(s)
        sp.edit().putString("web_knowledge", arr.toString()).apply()
    }

    fun clearWebKnowledge() {
        sp.edit().putString("web_knowledge", "[]").apply()
    }

    /** سجل المنبهات التي أنشأها المساعد: وقت HH:mm -> حالة ووقت الإنشاء. */
    fun alarmState(key: String): Boolean? {
        return try {
            val item = JSONObject(sp.getString("assistant_alarms", "{}")).optJSONObject(key) ?: return null
            val at = item.optLong("at", 0L)
            if (item.optBoolean("enabled", true) && at > 0L && at < System.currentTimeMillis() - 120_000L) {
                null // منبه لمرة واحدة مضى وقته، فلا نمنع جدولة اليوم التالي.
            } else {
                item.optBoolean("enabled", true)
            }
        } catch (e: Exception) {
            null
        }
    }

    fun saveAlarmState(key: String, enabled: Boolean, scheduledAt: Long) {
        val obj = try { JSONObject(sp.getString("assistant_alarms", "{}")) } catch (_: Exception) { JSONObject() }
        obj.put(key, JSONObject().put("enabled", enabled).put("at", scheduledAt))
        sp.edit().putString("assistant_alarms", obj.toString()).apply()
    }
}
