package com.example.myassistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** منبهات التطبيق الداخلية: يمكن قراءتها وإدارتها بالكامل من داخل المساعد. */
object InternalAlarm {
    private const val PREFS = "internal_alarms"
    private const val CHANNEL = "internal_alarm"
    private const val ACTION = "com.example.myassistant.INTERNAL_ALARM"

    data class Item(val id: String, val hour: Int, val minute: Int, val label: String, val enabled: Boolean, val triggerAt: Long)

    fun all(ctx: Context): List<Item> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val result = mutableListOf<Item>()
        try {
            val arr = JSONArray(sp.getString("items", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(Item(o.getString("id"), o.getInt("hour"), o.getInt("minute"), o.optString("label", "مساعدي"), o.optBoolean("enabled", true), o.optLong("triggerAt", 0L)))
            }
        } catch (_: Exception) { }
        return result.sortedWith(compareBy<Item> { it.hour }.thenBy { it.minute })
    }

    fun findByTime(ctx: Context, hour: Int, minute: Int): Item? = all(ctx).firstOrNull { it.hour == hour && it.minute == minute }

    fun schedule(ctx: Context, hour: Int, minute: Int, label: String = "مساعدي"): Item {
        val old = findByTime(ctx, hour, minute)
        val id = old?.id ?: "$hour:$minute"
        val trigger = nextTrigger(hour, minute)
        val item = Item(id, hour, minute, label, true, trigger)
        save(ctx, item)
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(ctx, id, PendingIntent.FLAG_UPDATE_CURRENT)
        val info = AlarmManager.AlarmClockInfo(trigger, openPendingIntent(ctx))
        try {
            alarm.setAlarmClock(info, pi)
        } catch (_: SecurityException) {
            try {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            } catch (_: SecurityException) {
                // سيظهر المنبه في قائمة التطبيق حتى يمنح المستخدم صلاحية المنبهات الدقيقة.
            }
        }
        return item
    }

    fun disable(ctx: Context, item: Item): Item {
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingIntent(ctx, item.id, PendingIntent.FLAG_NO_CREATE))
        val updated = item.copy(enabled = false)
        save(ctx, updated)
        return updated
    }

    fun enable(ctx: Context, item: Item): Item = schedule(ctx, item.hour, item.minute, item.label)

    fun remove(ctx: Context, item: Item) {
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingIntent(ctx, item.id, PendingIntent.FLAG_NO_CREATE))
        val remaining = all(ctx).filterNot { it.id == item.id }
        write(ctx, remaining)
    }

    private fun save(ctx: Context, item: Item) {
        val list = all(ctx).filterNot { it.id == item.id }.toMutableList()
        list.add(item)
        write(ctx, list)
    }

    private fun write(ctx: Context, list: List<Item>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("hour", it.hour).put("minute", it.minute).put("label", it.label).put("enabled", it.enabled).put("triggerAt", it.triggerAt)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }

    private fun nextTrigger(hour: Int, minute: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun pendingIntent(ctx: Context, id: String, flags: Int): PendingIntent {
        val intent = Intent(ctx, InternalAlarmReceiver::class.java).setAction(ACTION).putExtra("id", id)
        return PendingIntent.getBroadcast(ctx, id.hashCode(), intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openPendingIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 9901, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun fire(ctx: Context, id: String) {
        val item = all(ctx).firstOrNull { it.id == id } ?: return
        val updated = item.copy(enabled = false)
        save(ctx, updated)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "منبهات المساعد", NotificationManager.IMPORTANCE_HIGH))
        val open = openPendingIntent(ctx)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(com.example.myassistant.R.drawable.ic_stat_mic)
            .setContentTitle("منبه مساعدي الذكي")
            .setContentText(item.label.ifBlank { "حان موعد المنبه" })
            .setStyle(NotificationCompat.BigTextStyle().bigText("حان موعد المنبه ${"%02d:%02d".format(item.hour, item.minute)}"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        nm.notify(7000 + (id.hashCode() and 0x0FFF), n)
    }
}

class InternalAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getStringExtra("id") ?: return
        InternalAlarm.fire(context, id)
    }
}
