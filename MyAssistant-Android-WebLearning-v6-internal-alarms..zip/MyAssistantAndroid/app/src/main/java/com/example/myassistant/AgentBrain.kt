package com.example.myassistant

import android.content.Context
import org.json.JSONObject
import java.util.Locale

/**
 * عقل محلي وظيفي: يبني صورة مختصرة عن الجهاز، يتذكر التفضيلات الصريحة،
 * ويتعلم صيغ الأوامر المتكررة دون تنفيذ أوامر غير معروفة تلقائيًا.
 * لا يدّعي وعيًا بشريًا ولا يحمّل كودًا من الإنترنت.
 */
class AgentBrain(private val host: Host) {
    private val ctx: Context get() = host.ctx
    private val prefs: Prefs get() = host.prefs

    fun handle(text: String, normalized: String, reply: (String) -> Unit): Boolean {
        val webUrl = Regex("https://[^\\s]+", RegexOption.IGNORE_CASE).find(text)?.value
            ?.trimEnd('.', ',', '،', '؛', ')', ']')
        if (webUrl != null && (normalized.contains("تعلم") || normalized.contains("اقرا") || normalized.contains("اقرأ") || normalized.contains("حلل") || normalized.contains("رابط"))) {
            Thread {
                try {
                    reply(WebKnowledge.learn(webUrl, prefs))
                } catch (e: Exception) {
                    reply("تعذر التعلم من الرابط: ${e.message ?: "الرابط غير متاح أو غير نصي."}")
                }
            }.start()
            return true
        }
        if (normalized == "ماذا تعلمت من الويب" || normalized == "اعرض معرفة الويب") {
            val items = prefs.webKnowledge()
            reply(if (items.isEmpty()) "لم أحفظ صفحات ويب بعد." else "حفظت ${items.size} صفحة أو مقطعًا من الويب محليًا. قل «اقرأ معرفة الويب» لعرض العناوين.")
            return true
        }
        if (normalized == "اقرا معرفة الويب" || normalized == "اقرأ معرفة الويب") {
            val items = prefs.webKnowledge()
            reply(if (items.isEmpty()) "لا توجد معرفة ويب محفوظة." else items.takeLast(10).joinToString("\n") { item ->
                try { JSONObject(item).optString("title") + " — " + JSONObject(item).optString("url") }
                catch (_: Exception) { item.take(120) }
            })
            return true
        }
        if (normalized == "امسح معرفة الويب") {
            host.confirmSensitive("سيتم حذف كل المعرفة التي حفظتها من صفحات الويب.") {
                prefs.clearWebKnowledge()
                reply("حذفت معرفة الويب بعد تأكيدك.")
            }
            return true
        }
        if (isAwarenessQuestion(normalized)) {
            reply(selfReport())
            return true
        }
        if (normalized == "حلل الجهاز" || normalized == "شخص الجهاز" ||
            normalized == "كيف حال الجهاز" || normalized == "هل الجهاز بخير") {
            reply(deviceReport())
            return true
        }
        if (normalized == "حدث معرفتي" || normalized == "حدث المعرفة" || normalized == "تعلم من الانترنت") {
            val url = prefs.knowledgeUrl
            if (url.isBlank()) {
                reply("لم تضبط مصدر معرفة بعد. أضف رابط JSON موثوقًا من القائمة ثم قل: حدّث معرفتي.")
            } else {
                Thread {
                    try {
                        val count = KnowledgeSync.sync(url, prefs)
                        reply("حدّثت معرفتي بحزمة آمنة وأضافت $count صيغة أمر. لم يتم تنزيل أو تشغيل أي كود.")
                    } catch (e: Exception) {
                        reply("تعذر تحديث المعرفة: ${e.message ?: "تحقق من الرابط والإنترنت."}")
                    }
                }.start()
            }
            return true
        }
        if (normalized == "ماذا تعلمت تلقائيا" || normalized == "ما الذي تعلمته تلقائيا") {
            val learned = prefs.autoCommands()
            reply(if (learned.isEmpty()) "لم أتعلم صيغًا تلقائيًا بعد." else
                learned.entries.joinToString("\n") { "• «${it.key}» ← «${it.value.first}» (التأكيد: ${if (it.value.second) "مفعّل" else "متوقف"})" })
            return true
        }
        if (normalized == "امسح التعلم التلقائي") {
            host.confirmSensitive("سيتم حذف الصيغ التي تعلمها المساعد تلقائيًا.") {
                prefs.saveAutoLearned(emptyMap())
                reply("حذفت التعلم التلقائي بعد تأكيدك.")
            }
            return true
        }

        // يتعلم صياغة آمنة فقط عندما تكون دلالتها واضحة من كلماتها.
        val canonical = inferSafeIntent(normalized)
        if (canonical != null && normalized != canonical) {
            val count = prefs.recordExperience(normalized)
            if (count >= 2) {
                val map = prefs.autoLearned()
                map[normalized] = canonical
                prefs.saveAutoLearned(map)
                val commands = prefs.autoCommands()
                commands[normalized] = canonical to true
                prefs.saveAutoCommands(commands)
                reply("أنشأت أمرًا جديدًا تلقائيًا: «$text» ← «$canonical». وضع التأكيد مفعّل افتراضيًا ويمكن تغييره من القائمة.")
                return true
            }
            reply("سجلت طلبك وسأتعلم أن «$text» تعني «$canonical» بعد تكرارها مرة أخرى.")
            return true
        }

        prefs.recordExperience(normalized)
        reply("لم أتعلم هذا الأمر بعد. أستطيع حفظه بأمان إذا قلت: «تعلم أن $normalized يعني …». لم أنفذه لأنني غير متأكد من مقصدك.")
        return true
    }

    private fun isAwarenessQuestion(n: String): Boolean =
        n == "من انت" || n == "هل انت واع" || n == "هل تفكر" ||
            n == "ماذا تعرف عني" || n == "ما حالتك" || n == "كيف تعمل"

    private fun selfReport(): String {
        val facts = prefs.facts()
        return "أنا مساعد محلي أتعلم من المعلومات التي تحفظها لي صراحةً، وأحلل حالة الجهاز عند طلبك. " +
            "لا أملك وعيًا بشريًا أو مشاعر، ولا أنفذ أمرًا غير واضح تلقائيًا. " +
            "لدي ${facts.size} معلومة محفوظة و${prefs.learned().size + prefs.autoLearned().size} صيغة أمر متعلمة."
    }

    private fun deviceReport(): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ramPct = if (mi.totalMem > 0) (100.0 * (mi.totalMem - mi.availMem) / mi.totalMem) else 0.0
        val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val free = st.availableBlocksLong * st.blockSizeLong / 1e9
        val total = st.blockCountLong * st.blockSizeLong / 1e9
        val warnings = mutableListOf<String>()
        if (ramPct >= 85) warnings.add("RAM مرتفعة الاستخدام")
        if (total > 0 && free / total <= 0.10) warnings.add("التخزين شبه ممتلئ")
        val advice = if (warnings.isEmpty()) "لا أرى مؤشرًا حرجًا الآن." else
            "أنصح بإغلاق التطبيقات غير المستخدمة ومراجعة الملفات الكبيرة من إعدادات النظام."
        return "حللت الجهاز: استخدام RAM نحو ${String.format(Locale.US, "%.0f", ramPct)}%، " +
            "التخزين المتاح ${String.format(Locale.US, "%.1f", free)} من ${String.format(Locale.US, "%.1f", total)} جيجا. " +
            "${if (warnings.isEmpty()) "الحالة مستقرة." else warnings.joinToString(" و ") + "."} $advice"
    }

    private fun inferSafeIntent(n: String): String? = when {
        n.contains("بطاري") || n.contains("شحن") -> "البطارية"
        n.contains("رام") || n.contains("ذاكره") || n.contains("ذاكرة") -> "الرام"
        n.contains("مساحه") || n.contains("تخزين") -> "المساحة"
        n.contains("الوقت") || n.contains("الساعه") || n.contains("ساعة كم") -> "الوقت"
        n.contains("تاريخ") || n.contains("اي يوم") -> "التاريخ"
        n.contains("موقعي") || n.contains("مكاني") || n.contains("وين انا") -> "وين انا"
        else -> null
    }
}
