package com.example.myassistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.text.method.LinkMovementMethod
import android.text.util.Linkify
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener, Host {

    override val ctx: Context get() = this
    override lateinit var prefs: Prefs

    private lateinit var router: CommandRouter
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var btnMic: Button
    private lateinit var statusView: TextView

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false

    private var permCallback: ((Map<String, Boolean>) -> Unit)? = null
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val cb = permCallback
        permCallback = null
        cb?.invoke(result)
    }

    // ───────────────────────── دورة الحياة ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        router = CommandRouter(this)
        messages = findViewById(R.id.messages)
        scroll = findViewById(R.id.scroll)
        input = findViewById(R.id.input)
        btnMic = findViewById(R.id.btnMic)
        statusView = findViewById(R.id.statusView)
        val btnSend = findViewById<Button>(R.id.btnSend)
        val btnSos = findViewById<Button>(R.id.btnSos)
        val btnMenu = findViewById<TextView>(R.id.btnMenu)

        btnSos.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#C62828"))
        btnSos.setOnClickListener {
            toast("اضغط مطولًا على الزر لتفعيل الطوارئ (لتفادي الضغط بالخطأ).")
        }
        btnSos.setOnLongClickListener {
            triggerSos()
            true
        }

        btnSend.setOnClickListener { sendFromInput() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendFromInput()
                true
            } else {
                false
            }
        }
        btnMic.setOnClickListener { onMicClicked() }
        btnMenu.setOnClickListener { showMenu() }

        tts = TextToSpeech(this, this)

        if (prefs.handsFree && !ListenService.running) prefs.handsFree = false

        addBot(
            "أهلًا! أنا مساعدك الذكي. اضغط 🎤 وقل مثلًا «الوقت» أو «افتح واتساب»، أو اكتب أمرك. " +
                "ولتشغيل الاستماع في الخلفية (قل «يا مساعد») افتح القائمة ⋮ واختر «الوضع الحر». قل «مساعدة» لعرض الأوامر."
        )
        if (!prefs.firstRunDone) showFirstRun()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val r = tts?.setLanguage(Locale.forLanguageTag("ar")) ?: TextToSpeech.LANG_NOT_SUPPORTED
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            // تجاهل
        }
        setListening(false)
        tts?.stop()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    // ───────────────────────── الواجهة والرسائل ─────────────────────────

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun addMessage(msg: String, isUser: Boolean) {
        runOnUiThread {
            val tv = TextView(this)
            tv.text = msg
            tv.textSize = 16f
            tv.setTextColor(if (isUser) Color.WHITE else Color.parseColor("#1B1B1F"))
            tv.setLinkTextColor(if (isUser) Color.WHITE else Color.parseColor("#1565C0"))
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            val bg = GradientDrawable()
            bg.cornerRadius = dp(16).toFloat()
            bg.setColor(if (isUser) Color.parseColor("#1565C0") else Color.WHITE)
            tv.background = bg
            Linkify.addLinks(tv, Linkify.WEB_URLS)
            tv.movementMethod = LinkMovementMethod.getInstance()
            tv.maxWidth = (resources.displayMetrics.widthPixels * 0.86).toInt()
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = if (isUser) Gravity.START else Gravity.END
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            messages.addView(tv, lp)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    fun addBot(text: String) {
        addMessage(text, false)
        runOnUiThread { speak(text) }
    }

    private fun speak(text: String) {
        if (!prefs.ttsOn || !ttsReady) return
        val clean = text
            .replace(Regex("https?://\\S+"), " رابط ")
            .replace(Regex("[\\p{So}\\p{Cs}•]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(400)
        if (clean.isNotEmpty()) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    private fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        addMessage(t, true)
        try {
            router.handle(t) { reply -> addBot(reply) }
        } catch (e: Exception) {
            addBot("حصل خطأ غير متوقع: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun sendFromInput() {
        val t = input.text.toString()
        input.setText("")
        submit(t)
    }

    // ───────────────────────── الأذونات ─────────────────────────

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasLocationPermission(): Boolean =
        hasPerm(Manifest.permission.ACCESS_FINE_LOCATION) || hasPerm(Manifest.permission.ACCESS_COARSE_LOCATION)

    private fun requestPerms(perms: Array<String>, onResult: (Boolean) -> Unit) {
        val missing = perms.filter { !hasPerm(it) }
        if (missing.isEmpty()) {
            onResult(true)
            return
        }
        permCallback = { res -> onResult(perms.all { p -> res[p] == true || hasPerm(p) }) }
        permLauncher.launch(missing.toTypedArray())
    }

    // ───────────────────────── Host ─────────────────────────

    override fun launch(intent: Intent, label: String): Int {
        return try {
            startActivity(intent)
            Host.LAUNCHED
        } catch (e: Exception) {
            Host.LAUNCH_FAILED
        }
    }

    override fun withLocation(cb: (Location?) -> Unit) {
        requestPerms(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        ) { _ ->
            if (hasLocationPermission()) {
                LocationHelper.getLocation(this, 8000L, cb)
            } else {
                cb(null)
            }
        }
    }

    // ───────────────────────── الطوارئ ─────────────────────────

    override fun triggerSos() {
        addBot("🆘 جارٍ تفعيل الطوارئ… أحدد موقعك.")
        withLocation { loc -> deliverSos(loc) }
    }

    private fun deliverSos(loc: Location?) {
        val msg = Sos.buildMessage(loc)
        val contacts = prefs.emergencyContacts
        if (contacts.isEmpty()) {
            addBot(
                "لا توجد جهات اتصال طوارئ محفوظة، فلم أستطع الإرسال تلقائيًا. هذه رسالتك الجاهزة، " +
                    "اختر تطبيقًا لإرسالها، واضبط جهات الطوارئ من القائمة ⋮:\n\n$msg"
            )
            Sos.share(this, msg)
            return
        }
        if (prefs.autoSendSos) {
            requestPerms(arrayOf(Manifest.permission.SEND_SMS)) { ok ->
                if (ok) {
                    val sent = Sos.sendSms(this, contacts, msg)
                    addBot(
                        "أرسلت رسالة الطوارئ إلى $sent من ${contacts.size} جهة (لم يُتحقَّق من التسليم، راجع تطبيق الرسائل).\n" +
                            "إن كان الخطر حقيقيًا فاتصل أيضًا بأرقام الطوارئ المحلية.\n\n$msg"
                    )
                } else {
                    Sos.compose(this, contacts, msg)
                    addBot("لم يُمنح إذن الإرسال التلقائي، فتحت لك رسالة جاهزة — اضغط إرسال.\n\n$msg")
                }
            }
        } else {
            Sos.compose(this, contacts, msg)
            addBot(
                "فتحت لك رسالة طوارئ جاهزة لجهات الاتصال — اضغط إرسال.\n" +
                    "إن كان الخطر حقيقيًا فاتصل أيضًا بأرقام الطوارئ المحلية.\n\n$msg"
            )
        }
    }

    // ───────────────────────── الميكروفون (الضغط للتحدث) ─────────────────────────

    private fun onMicClicked() {
        if (listening) {
            recognizer?.stopListening()
            return
        }
        tts?.stop()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addBot("خدمة التعرف على الصوت غير متوفرة على جهازك (تحتاج تطبيق Google). يمكنك كتابة أمرك بدلًا من ذلك.")
            return
        }
        requestPerms(arrayOf(Manifest.permission.RECORD_AUDIO)) { granted ->
            if (granted) {
                beginRecognition()
            } else {
                addBot("أحتاج إذن الميكروفون لأسمعك. يمكنك منحه من إعدادات التطبيق، أو الكتابة بدلًا من ذلك.")
            }
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
        }

        override fun onBeginningOfSpeech() {
        }

        override fun onRmsChanged(rmsdB: Float) {
        }

        override fun onBufferReceived(buffer: ByteArray?) {
        }

        override fun onEndOfSpeech() {
        }

        override fun onError(error: Int) {
            setListening(false)
            if (error == SpeechRecognizer.ERROR_CLIENT) return
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                try {
                    recognizer?.cancel()
                } catch (e: Exception) {
                    // تجاهل
                }
            }
            addBot(errorText(error))
        }

        override fun onResults(results: Bundle?) {
            setListening(false)
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            input.setText("")
            if (text.isNullOrBlank()) {
                addBot("ما سمعت شيئًا واضحًا، حاول مرة ثانية.")
            } else {
                submit(text)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) input.setText(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {
        }
    }

    private fun beginRecognition() {
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(recognitionListener)
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.speechLang)
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            setListening(true)
            recognizer?.startListening(i)
        } catch (e: Exception) {
            setListening(false)
            addBot("تعذر تشغيل التعرف على الصوت: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun setListening(on: Boolean) {
        listening = on
        // أثناء استخدام الميكروفون هنا نوقف تنصّت الخدمة مؤقتًا حتى لا يتعارضا.
        ListenService.paused = on
        btnMic.text = if (on) "⏹" else "🎤"
        statusView.visibility = if (on) View.VISIBLE else View.GONE
        statusView.text = "🎙️ أسمعك… تكلّم الآن"
    }

    private fun errorText(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            "ما سمعت شيئًا واضحًا. اضغط 🎤 وحاول مرة ثانية."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "تعذر الاتصال بخدمة الصوت. تحتاج إنترنت، أو حمّل حزمة العربية للتعرف دون اتصال من إعدادات تطبيق Google."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون غير ممنوح."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة الصوت مشغولة، حاول بعد لحظة."
        12, 13 -> "لغة التعرف غير متاحة على جهازك. غيّر «لغة الصوت» من القائمة ⋮."
        else -> "تعذر التعرف على الصوت (رمز $code). جرّب مرة ثانية أو اكتب أمرك."
    }

    // ───────────────────────── القائمة ─────────────────────────

    private fun showMenu() {
        val items = arrayOf(
            if (ListenService.running) "⏹ إيقاف الوضع الحر (الخلفية)" else "🎙️ تشغيل الوضع الحر (الخلفية)",
            "🧠 تدريب كلمة «يا مساعد»",
            "🎚️ حساسية الكلمة",
            if (prefs.wakeDebug) "🧪 إيقاف وضع الاختبار" else "🧪 تشغيل وضع الاختبار",
            "🔓 إعدادات الخلفية (الظهور فوق التطبيقات / البطارية)",
            "🆘 جهات اتصال الطوارئ",
            "🗣️ لغة الصوت: ${prefs.speechLang}",
            if (prefs.ttsOn) "🔇 إيقاف نطق الردود" else "🔊 تشغيل نطق الردود",
            "📋 أمثلة الأوامر",
            "ℹ️ الأذونات والخصوصية"
        )
        AlertDialog.Builder(this)
            .setTitle("القائمة")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> toggleHandsFree()
                    1 -> showTrainDialog(false)
                    2 -> showSensitivityDialog()
                    3 -> {
                        prefs.wakeDebug = !prefs.wakeDebug
                        toast(
                            if (prefs.wakeDebug) "وضع الاختبار مفعّل: ستظهر نتيجة كل محاولة تعرّف أثناء الوضع الحر."
                            else "تم إيقاف وضع الاختبار."
                        )
                    }
                    4 -> showBackgroundSettings()
                    5 -> showContactsDialog()
                    6 -> showLanguageDialog()
                    7 -> {
                        prefs.ttsOn = !prefs.ttsOn
                        toast(if (prefs.ttsOn) "تم تشغيل النطق" else "تم إيقاف النطق")
                    }
                    8 -> submit("مساعدة")
                    9 -> showFirstRun()
                }
            }
            .show()
    }

    private fun showLanguageDialog() {
        val codes = arrayOf("ar-EG", "ar-SA", "ar-AE", "ar-MA", "ar", "en-US")
        val names = arrayOf(
            "العربية — مصر", "العربية — السعودية", "العربية — الإمارات",
            "العربية — المغرب", "العربية (عامة)", "English (US)"
        )
        AlertDialog.Builder(this)
            .setTitle("لغة التعرف على الصوت")
            .setItems(names) { _, which ->
                prefs.speechLang = codes[which]
                toast("تم الاختيار: ${names[which]}")
            }
            .show()
    }

    private fun showSensitivityDialog() {
        val names = arrayOf(
            "صارمة (إنذارات كاذبة أقل)",
            "متوسطة",
            "متساهلة (تلتقط نطقك بسهولة أكبر)"
        )
        AlertDialog.Builder(this)
            .setTitle("حساسية كلمة التنبيه")
            .setSingleChoiceItems(names, prefs.wakeSensitivity) { d, which ->
                prefs.wakeSensitivity = which
                d.dismiss()
                toast("تم الاختيار: ${names[which]}")
            }
            .show()
    }

    private fun showFirstRun() {
        val msg = """
            مرحبًا بك في «مساعدي الذكي». هذا ما يفعله التطبيق وما يحتاجه من أذونات:

            • الميكروفون: عند الضغط على 🎤 لسماع أمرك. وقد يُرسَل الصوت إلى خدمة التعرف الخاصة بـ Google إن لم تكن حزمة العربية للعمل دون اتصال محمّلة.
            • الوضع الحر (اختياري): إذا شغّلته يبقى التطبيق يستمع في الخلفية مع إشعار دائم بأيقونة ميكروفون. يبحث محليًا على جهازك عن عبارة «يا مساعد» فقط بأرقام ميزات صوتك المحفوظة، ولا يُحفظ أي تسجيل. وبعد سماعها يستمع لأمرك عبر خدمة التعرف في أندرويد. يستهلك بطارية إضافية.
            • الموقع: للطقس في موقعك وأمر «وين أنا» ورسالة الطوارئ.
            • الرسائل (اختياري): لإرسال موقعك تلقائيًا لجهات الطوارئ التي تحددها أنت، وفقط عند تفعيل الطوارئ.
            • الإنترنت: للطقس وفتح روابط البحث.

            تُحفظ بياناتك على هاتفك فقط (الملاحظات وجهات الطوارئ وقوالب الصوت)، ولا يوجد حساب ولا خادم.
        """.trimIndent()
        AlertDialog.Builder(this)
            .setTitle("قبل أن نبدأ")
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("فهمت، ابدأ") { _, _ -> prefs.firstRunDone = true }
            .setNeutralButton("إعداد جهات الطوارئ") { _, _ ->
                prefs.firstRunDone = true
                showContactsDialog()
            }
            .show()
    }

    private fun showContactsDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), 0)

        val info = TextView(this)
        info.text = "أرقام يصلها موقعك عند تفعيل الطوارئ (5 كحد أقصى، افصل بينها بفاصلة). " +
            "لا تُرسل أي رسالة إلا عندما تفعّل الطوارئ بنفسك."
        val et = EditText(this)
        et.hint = "مثال: +201012345678, +201112345678"
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setText(prefs.emergencyContacts.joinToString(", "))
        val cb = CheckBox(this)
        cb.text = "إرسال SMS تلقائيًا (يلزم إذن الرسائل، وهو ضروري لعمل الطوارئ الصوتية في الخلفية). " +
            "وإلا تُفتح لك رسالة جاهزة لتضغط إرسال."
        cb.isChecked = prefs.autoSendSos
        box.addView(info)
        box.addView(et)
        box.addView(cb)

        AlertDialog.Builder(this)
            .setTitle("جهات اتصال الطوارئ")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val numbers = et.text.toString()
                    .split(Regex("[,،;\\s]+"))
                    .map { Arabic.toAsciiDigits(it).replace(Regex("[^+\\d]"), "") }
                    .filter { it.length >= 5 }
                    .take(5)
                prefs.emergencyContacts = numbers
                prefs.autoSendSos = cb.isChecked
                toast("تم حفظ ${numbers.size} جهة.")
                if (cb.isChecked) {
                    requestPerms(arrayOf(Manifest.permission.SEND_SMS)) { ok ->
                        if (!ok) {
                            toast("لم يُمنح إذن الرسائل؛ سأفتح لك رسالة جاهزة بدل الإرسال التلقائي.")
                        }
                    }
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────────────────────── الوضع الحر (الخلفية) ─────────────────────────

    private fun toggleHandsFree() {
        if (ListenService.running) {
            ListenService.stop(this)
            prefs.handsFree = false
            addBot("أوقفت الوضع الحر.")
            return
        }
        enableHandsFree()
    }

    private fun enableHandsFree() {
        requestPerms(arrayOf(Manifest.permission.RECORD_AUDIO)) { granted ->
            if (!granted) {
                addBot("أحتاج إذن الميكروفون لتشغيل الوضع الحر.")
                return@requestPerms
            }
            if (Build.VERSION.SDK_INT >= 33) {
                requestPerms(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) { notifOk ->
                    if (!notifOk) {
                        toast("بدون إذن الإشعارات لن يظهر الإشعار الدائم، لكن الخدمة ستعمل.")
                    }
                    afterNotificationStep()
                }
            } else {
                afterNotificationStep()
            }
        }
    }

    private fun afterNotificationStep() {
        // الموقع اختياري، لكنه يلزم للطقس والطوارئ أثناء عمل التطبيق في الخلفية.
        requestPerms(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        ) { _ ->
            if (!WakeStore.hasTemplates(this)) {
                addBot("لازم أتعلم نطقك لعبارة «يا مساعد» أولًا، وبعدها أشغّل الوضع الحر.")
                showTrainDialog(true)
            } else {
                startHandsFree()
            }
        }
    }

    private fun startHandsFree() {
        try {
            ListenService.reload = true
            ListenService.start(this)
            addBot(
                "تم تشغيل الوضع الحر 🎙️\nسترى إشعارًا دائمًا بأيقونة ميكروفون. قل «يا مساعد» ثم انتظر النغمة وقل أمرك. " +
                    "إن لم يستجب فاضغط «🎤 تكلّم» في الإشعار، أو فعّل «وضع الاختبار» من القائمة لضبط الحساسية."
            )
        } catch (e: Exception) {
            addBot("تعذر تشغيل الوضع الحر: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun showTrainDialog(startAfter: Boolean) {
        requestPerms(arrayOf(Manifest.permission.RECORD_AUDIO)) { granted ->
            if (!granted) {
                addBot("أحتاج إذن الميكروفون للتدريب.")
                return@requestPerms
            }
            val tv = TextView(this)
            tv.setPadding(dp(20), dp(16), dp(20), dp(8))
            tv.textSize = 17f
            tv.text = "سأتعلم نطقك لعبارة «يا مساعد».\nاجلس في مكان هادئ وقلها بنبرة طبيعية 3 مرات، وانتظر ثانية بين كل مرة."
            val cancel = AtomicBoolean(false)
            val dlg = AlertDialog.Builder(this)
                .setTitle("تدريب كلمة التنبيه")
                .setView(tv)
                .setCancelable(false)
                .setNegativeButton("إلغاء") { _, _ -> cancel.set(true) }
                .create()
            dlg.show()
            ListenService.paused = true
            Thread {
                val err = try {
                    WakeTrainer.train(this, 3, cancel) { msg -> runOnUiThread { tv.text = msg } }
                } catch (e: Exception) {
                    "حصل خطأ أثناء التدريب: ${e.message ?: "غير معروف"}"
                }
                ListenService.paused = false
                ListenService.reload = true
                runOnUiThread {
                    if (dlg.isShowing) dlg.dismiss()
                    if (err == null) {
                        addBot("تم تدريب كلمة التنبيه ✔")
                        if (startAfter) {
                            startHandsFree()
                        } else {
                            addBot("يمكنك الآن تشغيل «الوضع الحر» من القائمة ⋮.")
                        }
                    } else {
                        addBot(err)
                    }
                }
            }.start()
        }
    }

    private fun showBackgroundSettings() {
        val msg = "لأفضل أداء في الخلفية:\n\n" +
            "1) «الظهور فوق التطبيقات»: يسمح للمساعد بفتح التطبيقات حين تطلب ذلك بصوتك وأنت لا تستخدمه. " +
            "بدونه يعرض إشعارًا تضغط عليه لإكمال الأمر.\n\n" +
            "2) استثناء البطارية: حتى لا يوقف النظام المساعد.\n\n" +
            "3) في أجهزة شاومي وهواوي وسامسونغ وغيرها: فعّل «التشغيل التلقائي» وثبّت التطبيق في قائمة التطبيقات الأخيرة."
        AlertDialog.Builder(this)
            .setTitle("إعدادات الخلفية")
            .setMessage(msg)
            .setPositiveButton("الظهور فوق التطبيقات") { _, _ -> openOverlaySettings() }
            .setNeutralButton("استثناء البطارية") { _, _ -> openBatterySettings() }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            toast("تعذر فتح الإعدادات. افتحها يدويًا من إعدادات التطبيق.")
        }
    }

    @SuppressLint("BatteryLife")
    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("تعذر فتح الإعدادات. افتحها يدويًا من إعدادات البطارية.")
            }
        }
    }
}
