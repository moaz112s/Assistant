package com.example.myassistant

import java.util.Locale

/** أدوات معالجة النص العربي. */
object Arabic {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u0640]")

    /** تحويل الأرقام العربية-الهندية إلى أرقام لاتينية. */
    fun toAsciiDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when (c) {
                in '\u0660'..'\u0669' -> sb.append('0' + (c - '\u0660'))
                in '\u06F0'..'\u06F9' -> sb.append('0' + (c - '\u06F0'))
                '\u066B' -> sb.append('.')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** نص خفيف: بلا تشكيل وبأرقام لاتينية، ويحافظ على الحروف كما هي (مناسب لأسماء المدن ونصوص الملاحظات). */
    fun light(s: String): String {
        var t = diacritics.replace(s, "")
        t = toAsciiDigits(t)
        t = t.replace(Regex("[؟?!،؛]"), " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    /** تطبيع كامل للمطابقة: توحيد الألف والتاء المربوطة والألف المقصورة. */
    fun normalize(s: String): String {
        var t = light(s).lowercase(Locale.ROOT)
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        t = t.replace('ة', 'ه').replace('ى', 'ي')
        return t.trim()
    }

    /** حذف عبارة النداء «يا مساعد» من أول الجملة. */
    fun stripWake(t: String): String =
        t.replace(Regex("^(يا\\s+)?(مساعدي|مساعد)(\\s+|$)"), "").trim()
}
