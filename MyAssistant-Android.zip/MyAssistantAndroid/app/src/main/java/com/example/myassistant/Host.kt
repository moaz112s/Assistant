package com.example.myassistant

import android.content.Context
import android.content.Intent
import android.location.Location

/**
 * الواجهة التي ينفّذها كلٌّ من الشاشة (MainActivity) وخدمة الخلفية (ListenService)،
 * حتى يعمل نفس موجّه الأوامر في الحالتين.
 */
interface Host {
    val ctx: Context
    val prefs: Prefs

    /** يشغّل نشاطًا (تطبيق، اتصال، ...). يعيد LAUNCHED أو PENDING_TAP أو LAUNCH_FAILED. */
    fun launch(intent: Intent, label: String): Int

    /** يحصل على الموقع (بعد طلب الإذن إن كان ممكنًا) ثم يستدعي cb. */
    fun withLocation(cb: (Location?) -> Unit)

    /** يفعّل الطوارئ. */
    fun triggerSos()

    companion object {
        const val LAUNCH_FAILED = 0
        const val LAUNCHED = 1
        const val PENDING_TAP = 2
    }
}
