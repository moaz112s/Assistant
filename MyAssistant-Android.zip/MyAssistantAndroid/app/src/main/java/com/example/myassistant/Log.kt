package com.example.myassistant

import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Date
import java.util.Locale

/** سجل أحداث الخدمة في الذاكرة فقط (لا يُحفظ على القرص) لتشخيص الأعطال. */
object ServiceLog {
    @Volatile var sessions = 0
    @Volatile var utterances = 0
    @Volatile var wakes = 0
    @Volatile var commands = 0
    private val lines = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun reset() {
        sessions = 0
        utterances = 0
        wakes = 0
        commands = 0
        lines.clear()
    }

    @Synchronized
    fun add(msg: String) {
        lines.add(fmt.format(Date()) + "  " + msg)
        while (lines.size > 80) lines.removeAt(0)
    }

    @Synchronized
    fun dump(): String {
        val head = "جلسات التعرف: $sessions | كلام مسموع: $utterances | نداءات «يا مساعد»: $wakes | أوامر: $commands"
        if (lines.isEmpty()) return head + "\n\nلا توجد أحداث بعد. شغّل الوضع الحر ثم جرّب."
        val start = Math.max(0, lines.size - 40)
        return head + "\n\n" + lines.subList(start, lines.size).joinToString("\n")
    }
}
