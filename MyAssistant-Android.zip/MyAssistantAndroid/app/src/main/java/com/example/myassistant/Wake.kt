package com.example.myassistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/*
 * كشف كلمة التنبيه «يا مساعد» محليًا بالكامل وبلا إنترنت:
 *   الميكروفون -> كاشف كلام (VAD) -> ميزات MFCC -> مطابقة DTW مع قوالب سجّلها المستخدم بصوته.
 * لا يُحفظ أي صوت: نحتفظ فقط بأرقام الميزات لقوالب التدريب الثلاثة.
 */

object WakeConfig {
    const val SAMPLE_RATE = 16000
    const val CHUNK = 320 // 20 ملّي ثانية
}

/** استخراج ميزات MFCC. */
object Mfcc {
    private const val SR = 16000.0
    private const val FRAME = 400
    private const val HOP = 160
    private const val NFFT = 512
    private const val NMEL = 26
    private const val NCEP = 13
    private const val PRE = 0.97

    private val window = DoubleArray(FRAME) { 0.54 - 0.46 * Math.cos(2.0 * Math.PI * it / (FRAME - 1)) }
    private val filterbank: Array<DoubleArray> = buildFilterbank()
    private val dct: Array<DoubleArray> = Array(NCEP) { i ->
        DoubleArray(NMEL) { m -> Math.cos(Math.PI * i * (m + 0.5) / NMEL) }
    }

    private fun mel(f: Double): Double = 2595.0 * Math.log10(1.0 + f / 700.0)
    private fun imel(m: Double): Double = 700.0 * (Math.pow(10.0, m / 2595.0) - 1.0)

    private fun buildFilterbank(): Array<DoubleArray> {
        val fmin = 100.0
        val fmax = 7000.0
        val lo = mel(fmin)
        val hi = mel(fmax)
        val pts = DoubleArray(NMEL + 2) { i -> imel(lo + (hi - lo) * i / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { i -> Math.floor((NFFT + 1) * pts[i] / SR).toInt() }
        val fb = Array(NMEL) { DoubleArray(NFFT / 2 + 1) }
        for (m in 1..NMEL) {
            val l = bins[m - 1]
            val c = bins[m]
            val r = bins[m + 1]
            for (k in l until c) if (c > l) fb[m - 1][k] = (k - l).toDouble() / (c - l)
            for (k in c until r) if (r > c) fb[m - 1][k] = (r - k).toDouble() / (r - c)
        }
        return fb
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wlr = Math.cos(ang)
            val wli = Math.sin(ang)
            val half = len / 2
            var i = 0
            while (i < n) {
                var wr = 1.0
                var wi = 0.0
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val xr = re[i + k + half]
                    val xi = im[i + k + half]
                    val vr = xr * wr - xi * wi
                    val vi = xr * wi + xi * wr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + half] = ur - vr
                    im[i + k + half] = ui - vi
                    val nwr = wr * wlr - wi * wli
                    wi = wr * wli + wi * wlr
                    wr = nwr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** يعيد مصفوفة إطارات، كل إطار 13 قيمة مطبَّعة (CMVN). */
    fun compute(x: ShortArray): Array<FloatArray> {
        val n = x.size
        val y = DoubleArray(n)
        if (n > 0) y[0] = x[0].toDouble()
        for (i in 1 until n) y[i] = x[i].toDouble() - PRE * x[i - 1].toDouble()

        val frames = 1 + Math.max(0, (n - FRAME) / HOP)
        val feats = Array(frames) { DoubleArray(NCEP) }
        val re = DoubleArray(NFFT)
        val im = DoubleArray(NFFT)
        val melE = DoubleArray(NMEL)
        for (f in 0 until frames) {
            java.util.Arrays.fill(re, 0.0)
            java.util.Arrays.fill(im, 0.0)
            val off = f * HOP
            for (i in 0 until FRAME) {
                val idx = off + i
                re[i] = if (idx < n) y[idx] * window[i] else 0.0
            }
            fft(re, im)
            for (m in 0 until NMEL) {
                var s = 0.0
                val row = filterbank[m]
                for (k in 0..NFFT / 2) s += row[k] * (re[k] * re[k] + im[k] * im[k])
                melE[m] = Math.log(s + 1e-3)
            }
            for (i in 0 until NCEP) {
                var s = 0.0
                val row = dct[i]
                for (m in 0 until NMEL) s += row[m] * melE[m]
                feats[f][i] = s
            }
        }

        // تطبيع المتوسط والتباين لكل جملة
        val mu = DoubleArray(NCEP)
        val sd = DoubleArray(NCEP)
        for (f in 0 until frames) for (i in 0 until NCEP) mu[i] += feats[f][i]
        for (i in 0 until NCEP) mu[i] /= frames.toDouble()
        for (f in 0 until frames) for (i in 0 until NCEP) {
            val d = feats[f][i] - mu[i]
            sd[i] += d * d
        }
        for (i in 0 until NCEP) sd[i] = Math.sqrt(sd[i] / frames.toDouble()) + 1e-6
        return Array(frames) { f -> FloatArray(NCEP) { i -> ((feats[f][i] - mu[i]) / sd[i]).toFloat() } }
    }
}

/** مطابقة زمنية ديناميكية (DTW) بين تسلسلين من الميزات. */
object Dtw {
    fun distance(a: Array<FloatArray>, b: Array<FloatArray>): Float {
        val n = a.size
        val m = b.size
        if (n == 0 || m == 0) return 1e9f
        val ratio = n.toDouble() / m.toDouble()
        if (ratio < 0.55 || ratio > 1.8) return 1e9f
        val band = Math.max(12, (0.35 * Math.max(n, m)).toInt())
        val inf = 1e18f
        var prev = FloatArray(m + 1) { inf }
        var cur = FloatArray(m + 1) { inf }
        prev[0] = 0f
        for (i in 1..n) {
            java.util.Arrays.fill(cur, inf)
            val center = (i.toLong() * m / n).toInt()
            val j0 = Math.max(1, center - band)
            val j1 = Math.min(m, center + band)
            val ai = a[i - 1]
            for (j in j0..j1) {
                val bj = b[j - 1]
                var s = 0f
                for (k in ai.indices) {
                    val diff = ai[k] - bj[k]
                    s += diff * diff
                }
                val d = Math.sqrt(s.toDouble()).toFloat()
                var best = prev[j]
                if (cur[j - 1] < best) best = cur[j - 1]
                if (prev[j - 1] < best) best = prev[j - 1]
                cur[j] = d + best
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[m] / (n + m).toFloat()
    }
}

/** كاشف بداية الكلام ونهايته. يُغذَّى بقطع 20ms ويعيد الجملة كاملة عند انتهائها. */
class Vad {
    companion object {
        const val START_N = 3     // 60ms فوق العتبة لبدء الكلام
        const val END_SIL = 25    // 500ms سكوت لإنهاء الجملة
        const val PRE = 10        // 200ms قبل بداية الكلام
        const val MIN_CH = 20     // أقل مدة للجملة (0.4 ث)
        const val MAX_CH = 110    // أطول مدة للجملة (2.2 ث)
    }

    private var noise = 60.0
    private var speech = false
    private var run = 0
    private var sil = 0
    private var nChunks = 0
    private val pre = java.util.ArrayDeque<ShortArray>()
    private val buf = ArrayList<ShortArray>()

    fun reset() {
        noise = 60.0
        endSegment()
    }

    private fun endSegment() {
        speech = false
        run = 0
        sil = 0
        nChunks = 0
        pre.clear()
        buf.clear()
    }

    fun feed(chunk: ShortArray, len: Int): ShortArray? {
        var sum = 0.0
        for (i in 0 until len) {
            val v = chunk[i].toDouble()
            sum += v * v
        }
        val rms = if (len > 0) Math.sqrt(sum / len) else 0.0
        val startTh = Math.max(noise * 3.0, 140.0)
        val stopTh = Math.max(noise * 2.0, 90.0)
        val copy = chunk.copyOf(len)

        if (!speech) {
            pre.addLast(copy)
            if (pre.size > PRE) pre.pollFirst()
            if (rms > startTh) {
                run++
            } else {
                run = 0
                noise = Math.min(2000.0, Math.max(10.0, 0.98 * noise + 0.02 * rms))
            }
            if (run >= START_N) {
                speech = true
                buf.clear()
                buf.addAll(pre)
                sil = 0
                nChunks = buf.size
            }
            return null
        }

        buf.add(copy)
        nChunks++
        if (rms < stopTh) sil++ else sil = 0

        if (sil >= END_SIL) {
            val voiced = nChunks - sil
            var out: ShortArray? = null
            if (voiced in MIN_CH..MAX_CH) {
                val keep = Math.min(buf.size, buf.size - sil + 5)
                out = concat(buf, keep)
            }
            endSegment()
            return out
        }
        if (nChunks > MAX_CH + END_SIL) endSegment()
        return null
    }

    private fun concat(list: List<ShortArray>, count: Int): ShortArray {
        var total = 0
        for (i in 0 until count) total += list[i].size
        val out = ShortArray(total)
        var pos = 0
        for (i in 0 until count) {
            val c = list[i]
            System.arraycopy(c, 0, out, pos, c.size)
            pos += c.size
        }
        return out
    }
}

/** مطابقة جملة مع قوالب التدريب. */
class WakeMatcher(private val templates: List<Array<FloatArray>>, val base: Float) {

    fun score(x: ShortArray): Float {
        val f = Mfcc.compute(x)
        var best = 1e9f
        for (t in templates) {
            val d = Dtw.distance(f, t)
            if (d < best) best = d
        }
        return best
    }

    /** 0 صارمة، 1 متوسطة، 2 متساهلة. */
    fun threshold(sensitivity: Int): Float {
        val mult = when (sensitivity) {
            0 -> 1.35f
            2 -> 2.4f
            else -> 1.8f
        }
        return base * mult
    }
}

/** حفظ القوالب (أرقام ميزات فقط، لا صوت) في ملف داخل مساحة التطبيق الخاصة. */
object WakeStore {
    private const val FILE = "wake_templates.json"

    fun hasTemplates(ctx: Context): Boolean = File(ctx.filesDir, FILE).exists()

    fun clear(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }

    fun save(ctx: Context, templates: List<Array<FloatArray>>, base: Float) {
        val root = JSONObject()
        root.put("base", base.toDouble())
        val arr = JSONArray()
        for (t in templates) {
            val frames = JSONArray()
            for (fr in t) {
                val row = JSONArray()
                for (v in fr) row.put(v.toDouble())
                frames.put(row)
            }
            arr.put(frames)
        }
        root.put("templates", arr)
        File(ctx.filesDir, FILE).writeText(root.toString())
    }

    fun load(ctx: Context): WakeMatcher? {
        val f = File(ctx.filesDir, FILE)
        if (!f.exists()) return null
        return try {
            val root = JSONObject(f.readText())
            val base = root.getDouble("base").toFloat()
            val arr = root.getJSONArray("templates")
            val list = ArrayList<Array<FloatArray>>()
            for (i in 0 until arr.length()) {
                val frames = arr.getJSONArray(i)
                val t = Array(frames.length()) { fi ->
                    val row = frames.getJSONArray(fi)
                    FloatArray(row.length()) { k -> row.getDouble(k).toFloat() }
                }
                list.add(t)
            }
            if (list.isEmpty()) null else WakeMatcher(list, base)
        } catch (e: Exception) {
            null
        }
    }
}

object Audio {
    /** يفتح الميكروفون بإعدادات مناسبة للتعرف (16kHz أحادي). */
    @SuppressLint("MissingPermission")
    fun open(): AudioRecord? {
        val sr = WakeConfig.SAMPLE_RATE
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return null
        val size = Math.max(minBuf, WakeConfig.CHUNK * 2 * 8)
        return try {
            val r = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sr,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                size
            )
            if (r.state == AudioRecord.STATE_INITIALIZED) {
                r
            } else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}

/** تدريب كلمة التنبيه: تسجيل 3 نطقات وحساب العتبة. */
object WakeTrainer {

    /** يسجّل جملة واحدة (من أول كلام حتى سكوت). يعيد null عند انتهاء المهلة أو الإلغاء. */
    fun captureUtterance(timeoutMs: Long, cancel: AtomicBoolean): ShortArray? {
        val rec = Audio.open() ?: return null
        val vad = Vad()
        val buf = ShortArray(WakeConfig.CHUNK)
        val t0 = System.currentTimeMillis()
        try {
            rec.startRecording()
            while (!cancel.get() && System.currentTimeMillis() - t0 < timeoutMs) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                val u = vad.feed(buf, n)
                if (u != null) return u
            }
        } catch (e: Exception) {
            // نعيد null
        } finally {
            try {
                rec.stop()
            } catch (e: Exception) {
                // تجاهل
            }
            rec.release()
        }
        return null
    }

    /** يعيد null عند النجاح، أو رسالة خطأ. */
    fun train(ctx: Context, count: Int, cancel: AtomicBoolean, status: (String) -> Unit): String? {
        val feats = ArrayList<Array<FloatArray>>()
        var attempts = 0
        while (feats.size < count && attempts < count * 4) {
            if (cancel.get()) return "أُلغي التدريب."
            attempts++
            status("قل «يا مساعد» الآن (المرة ${feats.size + 1} من $count)…")
            val u = captureUtterance(12000L, cancel)
            if (cancel.get()) return "أُلغي التدريب."
            if (u == null) {
                status("ما سمعت شيئًا، حاول مرة ثانية…")
                continue
            }
            val f = Mfcc.compute(u)
            if (f.size < 35 || f.size > 170) {
                status("النطق كان قصيرًا أو طويلًا جدًا. قل «يا مساعد» بنبرة طبيعية…")
                try {
                    Thread.sleep(1200)
                } catch (e: InterruptedException) {
                    return "أُلغي التدريب."
                }
                continue
            }
            feats.add(f)
            status("تمام ✔ (${feats.size} من $count)")
            try {
                Thread.sleep(900)
            } catch (e: InterruptedException) {
                return "أُلغي التدريب."
            }
        }
        if (feats.size < count) {
            return "لم أستطع تسجيل $count نطقات واضحة. جرّب في مكان أهدأ وبنطق متقارب."
        }
        var base = 0f
        for (i in feats.indices) {
            for (j in i + 1 until feats.size) {
                val d = Dtw.distance(feats[i], feats[j])
                if (d > base) base = d
            }
        }
        if (base >= 1e8f) return "أطوال النطقات مختلفة كثيرًا. أعد التدريب بنطق متقارب."
        if (base > 2.6f) return "النطقات غير متقاربة بما يكفي. أعد التدريب بنطق ثابت وبنفس السرعة."
        WakeStore.save(ctx, feats, base)
        return null
    }
}
