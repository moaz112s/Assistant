package com.example.myassistant

import java.util.Locale

/** حاسبة تعبيرات آمنة (لا تستخدم eval): + - * / ^ وأقواس. */
object Calc {

    fun eval(expr: String): Double {
        val p = Parser(expr)
        val v = p.parseExpression()
        p.skipWs()
        if (p.pos < p.s.length) throw IllegalArgumentException("unexpected input")
        return v
    }

    fun fmt(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return String.format(Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')
    }

    private class Parser(val s: String) {
        var pos = 0

        fun skipWs() {
            while (pos < s.length && s[pos].isWhitespace()) pos++
        }

        private fun peek(): Char? {
            skipWs()
            return if (pos < s.length) s[pos] else null
        }

        fun parseExpression(): Double {
            var v = parseTerm()
            var more = true
            while (more) {
                when (peek()) {
                    '+' -> { pos++; v += parseTerm() }
                    '-' -> { pos++; v -= parseTerm() }
                    else -> more = false
                }
            }
            return v
        }

        private fun parseTerm(): Double {
            var v = parsePower()
            var more = true
            while (more) {
                when (peek()) {
                    '*' -> { pos++; v *= parsePower() }
                    '/' -> {
                        pos++
                        val d = parsePower()
                        if (d == 0.0) throw ArithmeticException("division by zero")
                        v /= d
                    }
                    else -> more = false
                }
            }
            return v
        }

        private fun parsePower(): Double {
            val base = parseUnary()
            if (peek() == '^') {
                pos++
                return Math.pow(base, parsePower())
            }
            return base
        }

        private fun parseUnary(): Double {
            val c = peek()
            if (c == '-') { pos++; return -parseUnary() }
            if (c == '+') { pos++; return parseUnary() }
            return parsePrimary()
        }

        private fun parsePrimary(): Double {
            val c = peek() ?: throw IllegalArgumentException("unexpected end")
            if (c == '(') {
                pos++
                val v = parseExpression()
                if (peek() != ')') throw IllegalArgumentException("missing )")
                pos++
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("number expected")
            return s.substring(start, pos).toDouble()
        }
    }
}
