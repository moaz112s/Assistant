package com.example.myassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** تخزين محلي بسيط على الهاتف فقط (لا يُرسل لأي مكان). */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("assistant_prefs", Context.MODE_PRIVATE)

    var firstRunDone: Boolean
        get() = sp.getBoolean("first_run_done", false)
        set(v) { sp.edit().putBoolean("first_run_done", v).apply() }

    var ttsOn: Boolean
        get() = sp.getBoolean("tts_on", true)
        set(v) { sp.edit().putBoolean("tts_on", v).apply() }

    var speechLang: String
        get() = sp.getString("speech_lang", "ar-EG") ?: "ar-EG"
        set(v) { sp.edit().putString("speech_lang", v).apply() }

    var autoSendSos: Boolean
        get() = sp.getBoolean("auto_send_sos", false)
        set(v) { sp.edit().putBoolean("auto_send_sos", v).apply() }

    var emergencyContacts: List<String>
        get() = (sp.getString("emergency_contacts", "") ?: "")
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("emergency_contacts", v.joinToString(",")).apply() }

    var handsFree: Boolean
        get() = sp.getBoolean("hands_free", false)
        set(v) { sp.edit().putBoolean("hands_free", v).apply() }

    /** 0 صارمة، 1 متوسطة، 2 متساهلة. */
    var wakeSensitivity: Int
        get() = sp.getInt("wake_sensitivity", 1)
        set(v) { sp.edit().putInt("wake_sensitivity", v).apply() }

    /** عند التفعيل تظهر نتيجة كل محاولة تعرّف (للضبط). */
    var wakeDebug: Boolean
        get() = sp.getBoolean("wake_debug", false)
        set(v) { sp.edit().putBoolean("wake_debug", v).apply() }

    /** 0 = الاستماع عبر خدمة Google (يفهم الأمر في جملة واحدة)، 1 = كشف محلي بصوتك. */
    var wakeMode: Int
        get() = sp.getInt("wake_mode", 0)
        set(v) { sp.edit().putInt("wake_mode", v).apply() }

    /** السماح بإرسال الصوت للإنترنت أثناء الاستماع عبر Google. */
    var allowOnline: Boolean
        get() = sp.getBoolean("allow_online", false)
        set(v) { sp.edit().putBoolean("allow_online", v).apply() }

    var googleConsent: Boolean
        get() = sp.getBoolean("google_consent", false)
        set(v) { sp.edit().putBoolean("google_consent", v).apply() }

    fun notes(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(sp.getString("notes", "[]") ?: "[]")
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveNotes(list: List<String>) {
        val arr = JSONArray()
        for (s in list) arr.put(s)
        sp.edit().putString("notes", arr.toString()).apply()
    }

    /** العبارات المتعلَّمة: عبارة مطبَّعة -> أمر. */
    fun learned(): MutableMap<String, String> {
        val out = mutableMapOf<String, String>()
        try {
            val obj = JSONObject(sp.getString("learned", "{}") ?: "{}")
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                out[k] = obj.getString(k)
            }
        } catch (e: Exception) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    fun saveLearned(map: Map<String, String>) {
        val obj = JSONObject()
        for ((k, v) in map) obj.put(k, v)
        sp.edit().putString("learned", obj.toString()).apply()
    }
}
