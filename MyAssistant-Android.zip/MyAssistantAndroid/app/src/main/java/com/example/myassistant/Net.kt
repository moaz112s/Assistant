package com.example.myassistant

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Http {
    /** طلب GET بسيط. يجب استدعاؤه من خيط خلفي (ليس من الواجهة). */
    fun get(urlStr: String, timeoutMs: Int = 8000): String {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "MyAssistant-Android/1.0")
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}

/** الطقس عبر Open-Meteo (مجاني وبلا مفتاح). */
object Weather {

    fun byCity(city: String): String {
        val name = URLEncoder.encode(city, "UTF-8")
        val geo = JSONObject(
            Http.get("https://geocoding-api.open-meteo.com/v1/search?name=$name&count=1&language=ar&format=json")
        )
        val results = geo.optJSONArray("results")
        if (results == null || results.length() == 0) {
            return "ما لقيت مدينة باسم «$city». جرّب اسمًا آخر."
        }
        val r = results.getJSONObject(0)
        return byCoords(r.getDouble("latitude"), r.getDouble("longitude"), r.optString("name", city))
    }

    fun byCoords(lat: Double, lon: Double, label: String): String {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
            "&timezone=auto"
        val cur = JSONObject(Http.get(url)).getJSONObject("current")
        val temp = round0(cur.optDouble("temperature_2m", Double.NaN))
        val feels = round0(cur.optDouble("apparent_temperature", Double.NaN))
        val hum = round0(cur.optDouble("relative_humidity_2m", Double.NaN))
        val wind = round0(cur.optDouble("wind_speed_10m", Double.NaN))
        val desc = describe(cur.optInt("weather_code", -1))
        return "الطقس في ${label}: ${desc}، الحرارة ${temp}° (تُحَسّ كأنها ${feels}°)، الرطوبة ${hum}%، الرياح ${wind} كم/س."
    }

    private fun round0(d: Double): String = if (d.isNaN()) "—" else Math.round(d).toString()

    private fun describe(code: Int): String = when (code) {
        0 -> "سماء صافية"
        1 -> "صافٍ غالبًا"
        2 -> "غائم جزئيًا"
        3 -> "غائم"
        45, 48 -> "ضباب"
        51, 53, 55 -> "رذاذ"
        56, 57 -> "رذاذ متجمد"
        61, 63, 65 -> "مطر"
        66, 67 -> "مطر متجمد"
        71, 73, 75, 77 -> "ثلج"
        80, 81, 82 -> "زخات مطر"
        85, 86 -> "زخات ثلج"
        95 -> "عاصفة رعدية"
        96, 99 -> "عاصفة رعدية مع برد"
        else -> "حالة جوية غير معروفة"
    }
}
