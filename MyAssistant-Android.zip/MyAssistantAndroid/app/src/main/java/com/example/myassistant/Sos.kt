package com.example.myassistant

import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** رسالة الطوارئ وطرق إرسالها. */
object Sos {

    fun buildMessage(loc: Location?): String {
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        if (loc == null) {
            return "رسالة طوارئ: أحتاج مساعدة الآن! تعذّر تحديد موقعي.\nالوقت: $time"
        }
        val link = "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        val src = if (loc.provider == LocationManager.GPS_PROVIDER) "GPS" else "الشبكة"
        val ageMin = (System.currentTimeMillis() - loc.time) / 60000
        val age = if (ageMin >= 2) "\n(تنبيه: هذا آخر موقع معروف قبل $ageMin دقيقة)" else ""
        return "رسالة طوارئ: أحتاج مساعدة الآن!\nموقعي: $link\nالدقة: ${loc.accuracy.toInt()} متر ($src)$age\nالوقت: $time"
    }

    /** إرسال SMS مباشرة. يعيد عدد الأرقام التي قُبل الطلب لها. */
    fun sendSms(ctx: Context, numbers: List<String>, text: String): Int {
        var ok = 0
        try {
            val sm = smsManager(ctx)
            val parts = sm.divideMessage(text)
            for (n in numbers) {
                try {
                    sm.sendMultipartTextMessage(n, null, parts, null, null)
                    ok++
                } catch (e: Exception) {
                    // نكمل مع بقية الأرقام
                }
            }
        } catch (e: Exception) {
            // لا يوجد خدمة رسائل على الجهاز
        }
        return ok
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager {
        return if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
    }

    fun composeIntent(numbers: List<String>, text: String): Intent {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + numbers.joinToString(";")))
        i.putExtra("sms_body", text)
        return i
    }

    fun shareIntent(text: String): Intent {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, text)
        return Intent.createChooser(i, "إرسال رسالة الطوارئ عبر…")
    }

    /** يفتح تطبيق الرسائل برسالة جاهزة لجهات الطوارئ (المستخدم يضغط إرسال). */
    fun compose(ctx: Context, numbers: List<String>, text: String) {
        try {
            ctx.startActivity(composeIntent(numbers, text))
        } catch (e: Exception) {
            share(ctx, text)
        }
    }

    /** مشاركة النص عبر أي تطبيق (واتساب، تلغرام، ...). */
    fun share(ctx: Context, text: String) {
        try {
            ctx.startActivity(shareIntent(text))
        } catch (e: Exception) {
            // لا شيء
        }
    }
}
