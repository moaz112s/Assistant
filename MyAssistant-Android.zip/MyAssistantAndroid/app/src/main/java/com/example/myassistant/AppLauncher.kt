package com.example.myassistant

import android.content.Context
import android.content.Intent

/** البحث عن التطبيقات المثبتة وفتحها بالاسم. */
object AppLauncher {

    data class AppInfo(val label: String, val pkg: String)

    /** أسماء عربية شائعة -> اسم التطبيق بالإنجليزية كما يظهر عادةً في الهاتف. */
    private val aliases: Map<String, String> = mapOf(
        "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "واتس" to "whatsapp",
        "كروم" to "chrome", "جوجل كروم" to "chrome", "المتصفح" to "chrome",
        "يوتيوب" to "youtube",
        "تلغرام" to "telegram", "تليجرام" to "telegram", "تيليجرام" to "telegram",
        "فيسبوك" to "facebook", "فيس بوك" to "facebook", "ماسنجر" to "messenger",
        "انستغرام" to "instagram", "انستقرام" to "instagram", "انستجرام" to "instagram",
        "سناب شات" to "snapchat", "سناب" to "snapchat",
        "تيك توك" to "tiktok",
        "جيميل" to "gmail",
        "الخرائط" to "maps", "خرائط جوجل" to "maps",
        "الكاميرا" to "camera", "كاميرا" to "camera",
        "الاعدادات" to "settings", "اعدادات" to "settings",
        "الصور" to "photos",
        "الحاسبه" to "calculator", "الاله الحاسبه" to "calculator",
        "الساعه" to "clock", "المنبه" to "clock",
        "الهاتف" to "phone", "الاتصال" to "phone",
        "الرسائل" to "messages",
        "جهات الاتصال" to "contacts",
        "الملفات" to "files", "ملفاتي" to "files",
        "متجر بلاي" to "play store", "بلاي ستور" to "play store",
        "نتفلكس" to "netflix", "سبوتيفاي" to "spotify", "زوم" to "zoom",
        "ديسكورد" to "discord", "لينكد ان" to "linkedin",
        "التقويم" to "calendar"
    ).mapKeys { Arabic.normalize(it.key) }

    fun launchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val list = pm.queryIntentActivities(intent, 0)
        return list.map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
    }

    fun find(ctx: Context, spoken: String): AppInfo? {
        val q0 = Arabic.normalize(spoken)
        if (q0.isEmpty()) return null
        val candidates = listOfNotNull(aliases[q0], q0).distinct()
        val apps = launchable(ctx)
        val labels = apps.map { Arabic.normalize(it.label) }

        for (q in candidates) {
            // تطابق تام
            for (i in apps.indices) if (labels[i] == q) return apps[i]
            // يبدأ بالاسم
            for (i in apps.indices) if (labels[i].startsWith(q)) return apps[i]
            // يحتوي الاسم
            for (i in apps.indices) if (labels[i].contains(q)) return apps[i]
            // الجملة تحتوي اسم التطبيق (مثل: «تطبيق كروم»)
            for (i in apps.indices) if (labels[i].length >= 3 && q.contains(labels[i])) return apps[i]
        }
        // اسم الحزمة
        for (q in candidates) {
            val compact = q.replace(" ", "")
            if (compact.length >= 4) {
                for (a in apps) if (a.pkg.lowercase().contains(compact)) return a
            }
        }
        return null
    }

    fun intentFor(ctx: Context, app: AppInfo): Intent? {
        val i = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return null
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return i
    }
}
