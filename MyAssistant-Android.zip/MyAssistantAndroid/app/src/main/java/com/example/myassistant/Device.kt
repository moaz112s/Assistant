package com.example.myassistant

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import java.util.Locale

/** معلومات الجهاز: البطارية والذاكرة والتخزين. */
object DeviceInfo {

    fun battery(ctx: Context): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = st?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val suffix = if (charging) " (تُشحن)" else ""
        return "البطارية: $pct%$suffix"
    }

    fun memory(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / 1e9
        val avail = mi.availMem / 1e9
        return "الذاكرة (RAM): المتاح %.1f جيجا من %.1f جيجا".format(Locale.US, avail, total)
    }

    fun storage(): String {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong / 1e9
        val free = st.availableBlocksLong * st.blockSizeLong / 1e9
        return "التخزين: المتاح %.1f جيجا من %.1f جيجا".format(Locale.US, free, total)
    }

    fun all(ctx: Context): String =
        battery(ctx) + "\n" + memory(ctx) + "\n" + storage()
}

/** تحديد الموقع عبر LocationManager (بدون خدمات Google Play). */
object LocationHelper {

    /** آخر موقع معروف (الأحدث بين المزوّدات المتاحة). */
    @SuppressLint("MissingPermission")
    fun lastKnown(ctx: Context): Location? {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        val providers = try {
            lm.getProviders(true)
        } catch (e: Exception) {
            emptyList<String>()
        }
        for (p in providers) {
            val l = (try {
                lm.getLastKnownLocation(p)
            } catch (e: Exception) {
                null
            }) ?: continue
            val b = best
            if (b == null || l.time > b.time) best = l
        }
        return best
    }

    /** يحاول الحصول على موقع حديث خلال المهلة، وإلا يعيد آخر موقع معروف. يُستدعى من خيط الواجهة. */
    @SuppressLint("MissingPermission")
    fun getLocation(ctx: Context, timeoutMs: Long, cb: (Location?) -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val handler = Handler(Looper.getMainLooper())
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter {
            try {
                lm.isProviderEnabled(it)
            } catch (e: Exception) {
                false
            }
        }
        if (providers.isEmpty()) {
            cb(lastKnown(ctx))
            return
        }

        var done = false
        val listeners = mutableListOf<LocationListener>()

        fun finish(loc: Location?) {
            if (done) return
            done = true
            handler.removeCallbacksAndMessages(null)
            for (l in listeners) {
                try {
                    lm.removeUpdates(l)
                } catch (e: Exception) {
                    // تجاهل
                }
            }
            cb(loc ?: lastKnown(ctx))
        }

        for (p in providers) {
            val l = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    finish(location)
                }

                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
                }

                override fun onProviderEnabled(provider: String) {
                }

                override fun onProviderDisabled(provider: String) {
                }
            }
            listeners.add(l)
            try {
                lm.requestLocationUpdates(p, 0L, 0f, l, Looper.getMainLooper())
            } catch (e: Exception) {
                // قد يفشل GPS إذا مُنح الإذن التقريبي فقط
            }
        }
        handler.postDelayed({ finish(null) }, timeoutMs)
    }
}
