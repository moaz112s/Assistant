package com.example.myassistant

import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * يحوّل النص (المكتوب أو المنطوق) إلى أمر وينفّذه.
 * التوجيه بمطابقة كلمات عربية محلية، بلا أي ذكاء اصطناعي سحابي.
 * ملاحظة: دالة reply قد تُستدعى من أي خيط، وهي آمنة لذلك.
 */
class CommandRouter(private val h: Host) {

    private val sosPhrase = Arabic.normalize("طوارئ قصوى")
    private val arLocale: Locale = Locale.forLanguageTag("ar")

    fun handle(raw: String, reply: (String) -> Unit) {
        val rawLight = Arabic.light(raw)
        var n = Arabic.stripWake(Arabic.normalize(raw))
        if (n.isEmpty()) {
            reply("تفضّل، أنا أسمعك.")
            return
        }

        // الطوارئ: عبارة دقيقة فقط، بلا مرونة ولا عبارات متعلَّمة (لتقليل التفعيل الخاطئ).
        if (n == sosPhrase) {
            h.triggerSos()
            return
        }

        // عبارات علّمها المستخدم للمساعد.
        val mapped = h.prefs.learned()[n]
        if (mapped != null) {
            n = Arabic.normalize(mapped)
            if (n == sosPhrase) {
                reply("هذه العبارة المتعلَّمة غير مسموحة لأنها تفعّل الطوارئ.")
                return
            }
        }

        if (learnCommands(n, rawLight, reply)) return
        if (calc(n, reply)) return
        if (notes(n, rawLight, reply)) return
        if (timerOrAlarm(n, reply)) return
        if (communication(n, rawLight, reply)) return
        if (openApp(n, reply)) return
        if (search(n, rawLight, reply)) return
        if (weather(n, rawLight, reply)) return
        if (deviceStatus(n, reply)) return
        if (where(n, reply)) return
        if (timeDate(n, reply)) return
        if (social(n, reply)) return
        reply("ما فهمت «$raw». قل «مساعدة» لعرض الأوامر.")
    }

    // ───────────────────────── أدوات مساعدة ─────────────────────────

    /** يعيد النص الأصلي (بحروفه الأصلية) المقابل لجزء مطبَّع من آخر الجملة. */
    private fun original(tailNorm: String, rawLight: String): String {
        if (tailNorm.isEmpty()) return tailNorm
        if (rawLight.length >= tailNorm.length) {
            val cand = rawLight.takeLast(tailNorm.length)
            if (Arabic.normalize(cand) == tailNorm) return cand.trim()
        }
        return tailNorm
    }

    private fun startOrReply(i: Intent, ok: String, fail: String, reply: (String) -> Unit): Boolean {
        when (h.launch(i, ok)) {
            Host.LAUNCHED -> reply(ok)
            Host.PENDING_TAP -> reply("جهّزت الأمر. اضغط الإشعار لإكماله.")
            else -> reply(fail)
        }
        return true
    }

    private fun fmtDuration(sec: Int): String {
        val hrs = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = mutableListOf<String>()
        if (hrs > 0) parts.add("$hrs ساعة")
        if (m > 0) parts.add("$m دقيقة")
        if (s > 0) parts.add("$s ثانية")
        return parts.joinToString(" و ")
    }

    // ───────────────────────── التعلّم ─────────────────────────

    private fun learnCommands(n: String, rawLight: String, reply: (String) -> Unit): Boolean {
        val m = Regex("^تعلم(?:\\s+ان)?\\s+(.+?)\\s+يعني\\s+(.+)$").find(n)
        if (m != null) {
            val phrase = m.groupValues[1].trim()
            val targetNorm = m.groupValues[2].trim()
            if (phrase.isEmpty() || targetNorm.isEmpty() || phrase == sosPhrase || targetNorm == sosPhrase) {
                reply("لا يمكن ربط عبارات بالطوارئ، ولا استخدام عبارة فارغة.")
                return true
            }
            val target = original(targetNorm, rawLight)
            val map = h.prefs.learned()
            map[phrase] = target
            h.prefs.saveLearned(map)
            reply("تعلمت: «$phrase» تعني «$target».")
            return true
        }
        if (n == "ماذا تعلمت" || n == "شو تعلمت" || n == "ايش تعلمت") {
            val map = h.prefs.learned()
            if (map.isEmpty()) {
                reply("ما تعلمت أي عبارات بعد. جرّب: تعلم أن شغل عملي يعني افتح المفكرة")
            } else {
                reply(map.entries.joinToString("\n") { "• «${it.key}» ← «${it.value}»" })
            }
            return true
        }
        if (n == "امسح كل ما تعلمته" || n == "امسح كل ما تعلمت") {
            h.prefs.saveLearned(emptyMap())
            reply("مسحت كل العبارات المتعلَّمة.")
            return true
        }
        val f = Regex("^(?:انسي|انس)\\s+(.+)$").find(n)
        if (f != null) {
            val p = f.groupValues[1].trim()
            val map = h.prefs.learned()
            if (map.remove(p) != null) {
                h.prefs.saveLearned(map)
                reply("نسيت «$p».")
            } else {
                reply("ما عندي عبارة متعلَّمة بهذا الاسم.")
            }
            return true
        }
        return false
    }

    // ───────────────────────── الحاسبة ─────────────────────────

    private fun calc(n: String, reply: (String) -> Unit): Boolean {
        val prefixes = listOf("احسب", "حاسب", "كم يساوي", "كم ناتج", "كم حاصل")
        val p = prefixes.firstOrNull { n.startsWith(it) } ?: return false
        var e = " " + n.removePrefix(p).trim() + " "
        val words = listOf(
            " زائد " to " + ", " زايد " to " + ", " ناقص " to " - ", " طرح " to " - ",
            " ضرب " to " * ", " في " to " * ", " مضروبه في " to " * ",
            " تقسيم " to " / ", " قسمه " to " / ", " على " to " / "
        )
        for ((k, v) in words) e = e.replace(k, v)
        e = e.replace('×', '*').replace('÷', '/').replace('−', '-').replace('x', '*')
        try {
            val v = Calc.eval(e)
            reply("النتيجة: ${Calc.fmt(v)}")
        } catch (ex: ArithmeticException) {
            reply("لا يمكن القسمة على صفر.")
        } catch (ex: Exception) {
            reply("ما قدرت أحسب «${e.trim()}». جرّب مثل: احسب 5 + 3 * 2")
        }
        return true
    }

    // ───────────────────────── الملاحظات ─────────────────────────

    private fun notes(n: String, rawLight: String, reply: (String) -> Unit): Boolean {
        val saveP = listOf("احفظ ملاحظه", "سجل ملاحظه", "اضف ملاحظه", "دون ملاحظه")
            .firstOrNull { n.startsWith(it) }
        if (saveP != null) {
            val body = original(n.removePrefix(saveP).trim(), rawLight)
            if (body.isEmpty()) {
                reply("ما سمعت نص الملاحظة. قل مثلًا: احفظ ملاحظة شراء حليب")
                return true
            }
            val list = h.prefs.notes()
            list.add(body)
            h.prefs.saveNotes(list)
            reply("حفظت الملاحظة رقم ${list.size}: $body")
            return true
        }
        if (n == "الملاحظات" || n == "اعرض الملاحظات" || n == "ملاحظاتي" || n == "اقرا الملاحظات") {
            val list = h.prefs.notes()
            if (list.isEmpty()) {
                reply("ما عندك ملاحظات محفوظة.")
            } else {
                reply(list.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n"))
            }
            return true
        }
        if (n == "امسح الملاحظات" || n == "احذف الملاحظات" || n == "احذف كل الملاحظات") {
            h.prefs.saveNotes(emptyList())
            reply("مسحت كل الملاحظات.")
            return true
        }
        return false
    }

    // ───────────────────────── المؤقت والمنبه ─────────────────────────

    private fun timerOrAlarm(n: String, reply: (String) -> Unit): Boolean {
        if (n.startsWith("افتح")) return false

        val isTimer = n.contains("مؤقت") || n.contains("موقت") ||
            Regex("(نبهني|ذكرني|صحيني)\\s+بعد").containsMatchIn(n)
        if (isTimer) {
            var seconds = 0L
            val m = Regex("(\\d+)\\s*(ثان\\S*|ثوان\\S*|دقيق\\S*|دقا\\S*|ساع\\S*)").find(n)
            if (m != null) {
                val v = m.groupValues[1].toLongOrNull() ?: 0L
                val u = m.groupValues[2]
                seconds = when {
                    u.startsWith("ثان") || u.startsWith("ثوان") -> v
                    u.startsWith("دقيق") || u.startsWith("دقا") -> v * 60
                    else -> v * 3600
                }
            } else if (n.contains("نص ساعه")) {
                seconds = 1800L
            } else if (n.contains("ربع ساعه")) {
                seconds = 900L
            }
            if (seconds <= 0L || seconds > 86400L) {
                reply("كم المدة؟ مثال: مؤقت 5 دقائق")
                return true
            }
            val secs = seconds.toInt()
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "مساعدي")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return startOrReply(
                i,
                "ضبطت مؤقتًا لمدة ${fmtDuration(secs)}.",
                "ما لقيت تطبيق ساعة يدعم المؤقت على جهازك.",
                reply
            )
        }

        val isAlarm = n.contains("منبه") || n.startsWith("صحيني") || n.contains("نبهني الساعه")
        if (!isAlarm) return false

        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(n)
        if (m == null) {
            reply("أي ساعة؟ مثال: منبه الساعة 7:30 صباحًا")
            return true
        }
        var hour = m.groupValues[1].toInt()
        var min = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        if (m.groupValues[2].isEmpty()) {
            if (n.contains("ونص")) min = 30
            else if (n.contains("وربع")) min = 15
        }
        val pm = n.contains("مساء") || n.contains("عصرا") || n.contains("ليلا") || n.contains("بعد الظهر")
        val am = n.contains("صباحا") || n.contains("فجرا")
        if (pm && hour < 12) hour += 12
        if (am && hour == 12) hour = 0
        if (hour > 23 || min > 59) {
            reply("الوقت غير صحيح. مثال: منبه الساعة 7:30 صباحًا")
            return true
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "مساعدي")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val hh = hour.toString().padStart(2, '0')
        val mm = min.toString().padStart(2, '0')
        return startOrReply(
            i,
            "ضبطت منبهًا على $hh:$mm.",
            "ما لقيت تطبيق ساعة يدعم المنبه على جهازك.",
            reply
        )
    }

    // ───────────────────────── الاتصال والرسائل ─────────────────────────

    private fun communication(n: String, rawLight: String, reply: (String) -> Unit): Boolean {
        val numRegex = Regex("\\+?\\d[\\d\\s\\-]{5,}\\d")

        if (n.startsWith("اتصل") || n.startsWith("كلم ") || n.startsWith("رن على")) {
            val m = numRegex.find(n)
            if (m == null) {
                reply("الأسماء غير مدعومة بعد، قل رقم الهاتف. مثال: اتصل بـ 0123456789")
                return true
            }
            val number = m.value.replace(Regex("[\\s\\-]"), "")
            return startOrReply(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))),
                "فتحت شاشة الاتصال بالرقم $number — اضغط زر الاتصال.",
                "تعذر فتح تطبيق الهاتف.",
                reply
            )
        }

        val wantsSend = listOf("ارسل", "ابعت", "رساله", "راسل").any { n.startsWith(it) }
        if (!wantsSend) return false

        val isWa = n.contains("واتساب") || n.contains("واتس اب") || n.contains("whatsapp")
        val m = numRegex.find(n)
        if (m == null) {
            if (isWa) {
                reply("قل رقم واتساب صريحًا بالصيغة الدولية. مثال: ارسل واتساب إلى 201012345678 مرحبا")
            } else {
                reply("قل رقم الهاتف صريحًا. مثال: ارسل رسالة إلى 0123456789 مرحبا")
            }
            return true
        }
        val number = m.value.replace(Regex("[\\s\\-]"), "")
        val digits = number.replace(Regex("\\D"), "")
        val body = original(n.substring(m.range.last + 1).trim(), rawLight)

        if (isWa) {
            if (digits.startsWith("0")) {
                reply("واتساب يحتاج الرقم بالصيغة الدولية دون صفر في البداية، مثل 201012345678 لرقم مصري.")
                return true
            }
            val uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(body))
            return startOrReply(
                Intent(Intent.ACTION_VIEW, uri),
                "جهّزت رسالة واتساب إلى $digits — اضغط إرسال بنفسك.",
                "تعذر فتح واتساب.",
                reply
            )
        }
        val sms = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number))
        sms.putExtra("sms_body", body)
        return startOrReply(
            sms,
            "جهّزت رسالة نصية إلى $number — اضغط إرسال بنفسك.",
            "تعذر فتح تطبيق الرسائل.",
            reply
        )
    }

    // ───────────────────────── فتح التطبيقات والبحث ─────────────────────────

    private fun openApp(n: String, reply: (String) -> Unit): Boolean {
        val p = listOf("افتح", "شغل", "فتح", "افتحلي", "ابدا").firstOrNull { n.startsWith("$it ") }
            ?: return false
        var name = n.removePrefix(p).trim()
        name = name.replace(Regex("^(تطبيق|برنامج|لعبه|app)\\s+"), "").trim()
        if (name.isEmpty()) {
            reply("أي تطبيق تريد أن أفتح؟")
            return true
        }
        val app = AppLauncher.find(h.ctx, name)
        if (app == null) {
            reply("ما لقيت تطبيقًا باسم «$name» على جهازك.")
            return true
        }
        val launchIntent = AppLauncher.intentFor(h.ctx, app)
        if (launchIntent == null) {
            reply("تعذر فتح ${app.label}.")
            return true
        }
        return startOrReply(launchIntent, "فتحت ${app.label}.", "تعذر فتح ${app.label}.", reply)
    }

    private fun search(n: String, rawLight: String, reply: (String) -> Unit): Boolean {
        val p = listOf("ابحث عن", "ابحث", "دور على", "بحث عن").firstOrNull { n.startsWith(it) }
            ?: return false
        val q = original(n.removePrefix(p).trim(), rawLight)
        if (q.isEmpty()) {
            reply("عن ماذا تريد أن أبحث؟")
            return true
        }
        return startOrReply(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))),
            "أبحث عن «$q» في المتصفح.",
            "ما لقيت متصفحًا لفتح البحث.",
            reply
        )
    }

    // ───────────────────────── الطقس ─────────────────────────

    private fun weather(n: String, rawLight: String, reply: (String) -> Unit): Boolean {
        val tokens = n.split(" ")
        val asks = tokens.contains("الطقس") || tokens.contains("الجو") || n.contains("درجه الحراره")
        if (!asks) return false

        var city = ""
        val m = Regex("(?:^|\\s)(?:في|فى|ب)\\s+(.+)$").find(rawLight)
        if (m != null) {
            city = m.groupValues[1]
        } else {
            val m2 = Regex("(?:الطقس|الجو)\\s+(.+)$").find(rawLight)
            if (m2 != null) city = m2.groupValues[1]
        }
        city = city.replace(Regex("\\s*(اليوم|الان|الآن|حاليا|دلوقتي|دلوقت)\\s*$"), "").trim()
        if (city.startsWith("بال")) city = city.substring(1)

        if (city.isEmpty()) {
            h.withLocation { loc ->
                if (loc == null) {
                    reply("ما قدرت أحدد موقعك. قل اسم مدينة، مثل: الطقس في القاهرة.")
                } else {
                    Thread {
                        try {
                            reply(Weather.byCoords(loc.latitude, loc.longitude, "موقعك الحالي"))
                        } catch (e: Exception) {
                            reply("تعذر جلب الطقس. تأكد من اتصالك بالإنترنت.")
                        }
                    }.start()
                }
            }
        } else {
            Thread {
                try {
                    reply(Weather.byCity(city))
                } catch (e: Exception) {
                    reply("تعذر جلب الطقس. تأكد من اتصالك بالإنترنت.")
                }
            }.start()
        }
        return true
    }

    // ───────────────────────── حالة الجهاز والموقع والوقت ─────────────────────────

    private fun deviceStatus(n: String, reply: (String) -> Unit): Boolean {
        return when {
            n.contains("حاله الجهاز") || n.contains("حاله الهاتف") || n.contains("معلومات الجهاز") -> {
                reply(DeviceInfo.all(h.ctx)); true
            }
            n.contains("البطاريه") || n.contains("الشحن") -> {
                reply(DeviceInfo.battery(h.ctx)); true
            }
            n.contains("الرام") || n.contains("الذاكره") || n.contains("رامات") -> {
                reply(DeviceInfo.memory(h.ctx)); true
            }
            n.contains("المساحه") || n.contains("التخزين") || n.contains("الاقراص") -> {
                reply(DeviceInfo.storage()); true
            }
            else -> false
        }
    }

    private fun where(n: String, reply: (String) -> Unit): Boolean {
        val hit = listOf("وين انا", "اين انا", "موقعي", "مكاني", "وين موقعي").any { n.contains(it) }
        if (!hit) return false
        h.withLocation { loc ->
            if (loc == null) {
                reply("ما قدرت أحدد موقعك. فعّل خدمة الموقع (GPS) وامنح التطبيق إذن الموقع.")
            } else {
                val lat = String.format(Locale.US, "%.5f", loc.latitude)
                val lon = String.format(Locale.US, "%.5f", loc.longitude)
                reply("موقعك: $lat, $lon (الدقة ~${loc.accuracy.toInt()} متر)\nhttps://maps.google.com/?q=$lat,$lon")
            }
        }
        return true
    }

    private fun timeDate(n: String, reply: (String) -> Unit): Boolean {
        val now = Date()
        if (n.contains("كم الساعه") || n.contains("الساعه كم") || n.contains("الوقت") || n == "الساعه") {
            reply("الساعة الآن " + SimpleDateFormat("h:mm a", arLocale).format(now))
            return true
        }
        if (n.contains("التاريخ") || n.contains("اي يوم") || n.contains("ايش اليوم") || n.contains("اليوم كم")) {
            reply("اليوم " + SimpleDateFormat("EEEE d MMMM yyyy", arLocale).format(now))
            return true
        }
        return false
    }

    // ───────────────────────── ردود اجتماعية ومساعدة ─────────────────────────

    private val jokes = listOf(
        "قال المبرمج لزوجته: اذهبي واشتري حليبًا، وإذا وجدتِ بيضًا فاشتري ستة. رجعت ومعها ستة أكياس حليب، وقالت: وجدت بيضًا!",
        "لماذا الحاسوب دائمًا بارد؟ لأن نوافذه مفتوحة!",
        "سأل المعلم: من يعرف ما هو الفراغ؟ قال الطالب: هو الذي كان في رأسي قبل أن تسألني!"
    )

    private val helpText = """
        أمثلة على ما أفهمه:
        • الوقت / التاريخ
        • الطقس في القاهرة (أو «الطقس» وحدها لموقعك)
        • افتح واتساب / افتح كروم
        • ابحث عن مطاعم قريبة
        • احسب 5 + 3 * 2
        • احفظ ملاحظة شراء حليب / الملاحظات
        • مؤقت 10 دقائق / منبه الساعة 7:30 صباحًا
        • اتصل بـ 0123456789
        • ارسل واتساب إلى 201012345678 مرحبا
        • البطارية / الرام / المساحة / حالة الجهاز
        • وين أنا
        • تعلم أن شغل عملي يعني افتح المفكرة
        • طوارئ قصوى (أو اضغط مطولًا على زر 🆘)
    """.trimIndent()

    private fun social(n: String, reply: (String) -> Unit): Boolean {
        when {
            n == "مساعده" || n.contains("الاوامر") || n.contains("ايش تقدر") || n.contains("ماذا تستطيع") ->
                reply(helpText)
            n.contains("شكرا") -> reply("العفو! أنا في الخدمة.")
            n.contains("صباح الخير") -> reply("صباح النور!")
            n.contains("مساء الخير") -> reply("مساء النور!")
            n.contains("السلام عليكم") -> reply("وعليكم السلام ورحمة الله!")
            n.contains("مرحبا") || n.contains("اهلا") -> reply("أهلًا بك! كيف أقدر أساعدك؟")
            n.contains("نكته") -> reply(jokes[Random.nextInt(jokes.size)])
            n.contains("من انت") || n.contains("اسمك") ->
                reply("أنا «مساعدي الذكي» — نسخة الهاتف. أنفذ أوامر بسيطة مثل الوقت والطقس وفتح التطبيقات والملاحظات والطوارئ.")
            else -> return false
        }
        return true
    }
}
