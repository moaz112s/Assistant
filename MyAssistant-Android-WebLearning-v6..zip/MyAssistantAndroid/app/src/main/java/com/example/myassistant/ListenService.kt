package com.example.myassistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * خدمة الاستماع في الخلفية (Foreground Service) مع إشعار دائم بأيقونة ميكروفون.
 *
 * طريقتان للاستماع لعبارة «يا مساعد»:
 *  - wakeMode = 0 (الافتراضي): حلقة تعرّف مستمرة عبر خدمة التعرف في أندرويد. تفهم
 *    «يا مساعد افتح واتساب» في جملة واحدة وتنفّذها مباشرة.
 *  - wakeMode = 1: كشف محلي بصوتك (VAD + MFCC + DTW)، ثم يُستمع للأمر عبر خدمة التعرف.
 */
class ListenService : Service(), Host {

    companion object {
        const val ACTION_STOP = "com.example.myassistant.STOP"
        const val ACTION_LISTEN_NOW = "com.example.myassistant.LISTEN_NOW"
        private const val CHANNEL_LISTEN = "listen"
        private const val CHANNEL_ACTIONS = "actions"
        private const val NOTIF_ID = 1001
        private var actionNotifId = 2000

        @Volatile var running = false
        @Volatile var paused = false
        @Volatile var reload = true

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ListenService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ListenService::class.java))
        }
    }

    override val ctx: Context get() = this
    override lateinit var prefs: Prefs

    private lateinit var router: CommandRouter
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var stopFlag = false
    @Volatile private var listenNow = false
    @Volatile private var busy = false
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ttsCallbacks = HashMap<String, () -> Unit>()
    private var recognizer: SpeechRecognizer? = null

    // حالة طريقة Google
    private var sessionToken = 0
    private var awaitingUntil = 0L
    private var consecutiveErrors = 0
    private var offlineFails = 0
    private var lastCallbackAt = 0L
    private var sessionStartedAt = 0L
    private val restartRunnable = Runnable { gStart() }
    private val watcher = object : Runnable {
        override fun run() {
            if (stopFlag) return
            gWatch()
            main.postDelayed(this, 400)
        }
    }

    // ───────────────────────── دورة الحياة ─────────────────────────

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        router = CommandRouter(this)
        createChannels()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.forLanguageTag("ar")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                    }

                    override fun onDone(utteranceId: String?) {
                        finishUtterance(utteranceId)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        finishUtterance(utteranceId)
                    }
                })
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            prefs.handsFree = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (action == ACTION_LISTEN_NOW) {
            if (running) {
                if (prefs.wakeMode == 0) {
                    awaitingUntil = System.currentTimeMillis() + 8000
                    ServiceLog.add("زر «تكلّم»: بانتظار الأمر")
                    beep()
                    updateNotification("🎙️ أسمعك… قل أمرك")
                } else {
                    listenNow = true
                }
            }
            return START_NOT_STICKY
        }
        if (!running) {
            if (!goForeground()) {
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            prefs.handsFree = true
            acquireWakeLock()
            if (prefs.wakeMode == 0) startGoogleLoop() else startWorker()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopFlag = true
        running = false
        paused = false
        worker?.interrupt()
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // تجاهل
        }
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.stop()
        tts?.shutdown()
        tts = null
        ServiceLog.add("توقفت الخدمة")
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            // تجاهل
        }
        super.onDestroy()
    }

    // ───────────────────────── الإشعارات ─────────────────────────

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        val c1 = NotificationChannel(CHANNEL_LISTEN, "الاستماع في الخلفية", NotificationManager.IMPORTANCE_LOW)
        c1.description = "إشعار دائم يظهر طوال استماع المساعد لعبارة التنبيه."
        c1.setShowBadge(false)
        nm.createNotificationChannel(c1)
        val c2 = NotificationChannel(CHANNEL_ACTIONS, "تنبيهات المساعد", NotificationManager.IMPORTANCE_HIGH)
        c2.description = "أوامر بانتظار الضغط، وتنبيهات عن مشاكل الاستماع."
        nm.createNotificationChannel(c2)
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(status: String?): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_STOP), flags
        )
        val talkPi = PendingIntent.getService(
            this, 2, Intent(this, ListenService::class.java).setAction(ACTION_LISTEN_NOW), flags
        )
        val b = Notification.Builder(this, CHANNEL_LISTEN)
            .setSmallIcon(R.drawable.ic_stat_mic)
            .setContentTitle("مساعدي الذكي يستمع")
            .setContentText(status ?: "قل «يا ${prefs.assistantName}» ثم أمرك")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
        b.addAction(0, "🎤 تكلّم", talkPi)
        b.addAction(0, "⏹ إيقاف", stopPi)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    private fun updateNotification(status: String?) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(status))
        } catch (e: Exception) {
            // تجاهل
        }
    }

    private fun postProblem(text: String) {
        try {
            val n = Notification.Builder(this, CHANNEL_ACTIONS)
                .setSmallIcon(R.drawable.ic_stat_mic)
                .setContentTitle("مساعدي الذكي")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(actionNotifId++, n)
        } catch (e: Exception) {
            // تجاهل
        }
    }

    private fun goForeground(): Boolean {
        return try {
            val n = buildNotification(null)
            if (Build.VERSION.SDK_INT >= 30) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (hasLocation()) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                startForeground(NOTIF_ID, n, type)
            } else {
                startForeground(NOTIF_ID, n)
            }
            true
        } catch (e: Exception) {
            ServiceLog.add("تعذر بدء الخدمة الأمامية: " + (e.message ?: "؟"))
            Toast.makeText(this, "تعذر تشغيل الاستماع في الخلفية: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyAssistant:listen")
            wl.setReferenceCounted(false)
            wl.acquire()
            wakeLock = wl
        } catch (e: Exception) {
            // تجاهل
        }
    }

    // ───────────────────────── الطريقة 0: حلقة تعرّف مستمرة (Google) ─────────────────────────

    private fun startGoogleLoop() {
        stopFlag = false
        ServiceLog.reset()
        val net = if (prefs.allowOnline) "الإنترنت مسموح" else "دون اتصال فقط"
        ServiceLog.add("بدأ الاستماع المستمر عبر خدمة التعرف ($net)")
        main.post { gStart() }
        main.postDelayed(watcher, 400)
    }

    private fun scheduleRestart(ms: Long) {
        main.removeCallbacks(restartRunnable)
        if (!stopFlag) main.postDelayed(restartRunnable, ms)
    }

    /** يراقب الجلسة: يوقفها مؤقتًا عندما يستخدم التطبيق الميكروفون أو أثناء تنفيذ أمر، ويعيد تشغيل الجلسات العالقة. */
    private fun gWatch() {
        if (recognizer == null) return
        val now = System.currentTimeMillis()
        if (paused || busy) {
            destroyRecognizer()
            scheduleRestart(500)
        } else if (now - lastCallbackAt > 25000 && now - sessionStartedAt > 25000) {
            ServiceLog.add("الجلسة لم ترد منذ 25 ثانية، أعيد تشغيلها")
            destroyRecognizer()
            scheduleRestart(300)
        }
    }

    private fun gStart() {
        if (stopFlag || !running) return
        if (paused || busy) {
            scheduleRestart(500)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            ServiceLog.add("خدمة التعرف على الصوت غير متوفرة على الجهاز")
            updateNotification("⚠️ خدمة التعرف على الصوت غير متوفرة")
            scheduleRestart(5000)
            return
        }
        destroyRecognizer()
        try {
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = sr
            sessionToken++
            val token = sessionToken
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    lastCallbackAt = System.currentTimeMillis()
                }

                override fun onBeginningOfSpeech() {
                    lastCallbackAt = System.currentTimeMillis()
                }

                override fun onRmsChanged(rmsdB: Float) {
                }

                override fun onBufferReceived(buffer: ByteArray?) {
                }

                override fun onEndOfSpeech() {
                }

                override fun onError(error: Int) {
                    if (token == sessionToken) gOnError(error)
                }

                override fun onResults(results: Bundle?) {
                    if (token == sessionToken) gOnResults(results)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                }

                override fun onEvent(eventType: Int, params: Bundle?) {
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.speechLang)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !prefs.allowOnline)
            val now = System.currentTimeMillis()
            sessionStartedAt = now
            lastCallbackAt = now
            ServiceLog.sessions++
            sr.startListening(i)
        } catch (e: Exception) {
            ServiceLog.add("تعذر بدء جلسة التعرف: " + (e.message ?: "؟"))
            destroyRecognizer()
            scheduleRestart(2000)
        }
    }

    private fun gOnResults(results: Bundle?) {
        lastCallbackAt = System.currentTimeMillis()
        consecutiveErrors = 0
        offlineFails = 0
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (list != null && list.isNotEmpty()) gHeard(list)
        scheduleRestart(150)
    }

    private fun gOnError(code: Int) {
        lastCallbackAt = System.currentTimeMillis()
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                consecutiveErrors = 0
                scheduleRestart(120)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                ServiceLog.add("خطأ: إذن الميكروفون غير ممنوح")
                postProblem("إذن الميكروفون غير ممنوح، فتوقف الوضع الحر. امنح الإذن من إعدادات التطبيق.")
                prefs.handsFree = false
                stopSelf()
            }
            12, 13 -> {
                offlineFails++
                ServiceLog.add("لغة التعرف غير متاحة (رمز $code)")
                if (!prefs.allowOnline && offlineFails >= 3) {
                    postProblem(
                        "حزمة العربية للعمل دون اتصال غير متوفرة. حمّلها من إعدادات Google " +
                            "(الصوت ← التعرف على الكلام دون اتصال)، أو اسمح بالإنترنت من القائمة ← «طريقة الاستماع»."
                    )
                    prefs.handsFree = false
                    stopSelf()
                } else {
                    scheduleRestart(1500)
                }
            }
            else -> {
                consecutiveErrors++
                val delay = Math.min(10000L, 800L * consecutiveErrors)
                ServiceLog.add("خطأ تعرّف رمز $code (المحاولة $consecutiveErrors)")
                scheduleRestart(delay)
            }
        }
    }

    /** يعالج ما سمعته جلسة التعرف: نداء + أمر، أو نداء فقط، أو أمر بعد النداء. */
    private fun gHeard(list: List<String>) {
        ServiceLog.utterances++
        val now = System.currentTimeMillis()
        var rest: String? = null
        var matched = false
        for (t in list) {
            val r = Arabic.wakeRest(t, prefs.assistantName)
            if (r != null) {
                matched = true
                rest = r
                break
            }
        }
        if (matched) {
            ServiceLog.wakes++
            val cmd = rest ?: ""
            if (cmd.isEmpty()) {
                awaitingUntil = now + 8000
                ServiceLog.add("سمعت «يا ${prefs.assistantName}»، بانتظار الأمر")
                beep()
                updateNotification("🎙️ أسمعك… قل أمرك")
                main.postDelayed({
                    if (System.currentTimeMillis() >= awaitingUntil && !busy) updateNotification(null)
                }, 8200)
            } else {
                runCommand(cmd)
            }
            return
        }
        if (now < awaitingUntil) {
            awaitingUntil = 0L
            runCommand(list[0])
            return
        }
        if (prefs.wakeDebug) {
            ServiceLog.add("سمعت (بلا نداء): " + list[0].take(60))
        }
    }

    private fun runCommand(text: String) {
        busy = true
        ServiceLog.commands++
        ServiceLog.add("أمر: " + text.take(80))
        updateNotification("⚙️ أنفّذ الأمر…")
        val release = Runnable {
            busy = false
            updateNotification(null)
        }
        main.postDelayed(release, 30000)
        handleText(text) {
            main.removeCallbacks(release)
            main.postDelayed(release, 400)
        }
    }

    // ───────────────────────── الطريقة 1: كشف محلي بصوتك ─────────────────────────

    private fun startWorker() {
        stopFlag = false
        ServiceLog.reset()
        ServiceLog.add("بدأ الكشف المحلي لكلمة التنبيه")
        val t = Thread { loop() }
        t.name = "wake-loop"
        worker = t
        t.start()
    }

    private fun sleepQuiet(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            // تجاهل
        }
    }

    private fun loop() {
        val buf = ShortArray(WakeConfig.CHUNK)
        val vad = Vad()
        var matcher: WakeMatcher? = null
        while (!stopFlag) {
            if (reload) {
                matcher = WakeStore.load(this)
                reload = false
            }
            val m = matcher
            if (paused || m == null) {
                if (m == null) reload = true
                sleepQuiet(400)
                continue
            }
            val rec = Audio.open()
            if (rec == null) {
                ServiceLog.add("تعذر فتح الميكروفون")
                sleepQuiet(1500)
                continue
            }
            var wake = false
            try {
                rec.startRecording()
                vad.reset()
                while (!stopFlag && !paused && !wake) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    if (n == 0) continue
                    if (listenNow) {
                        listenNow = false
                        wake = true
                        break
                    }
                    val u = vad.feed(buf, n)
                    if (u != null) {
                        ServiceLog.utterances++
                        val score = m.score(u)
                        val th = m.threshold(prefs.wakeSensitivity)
                        if (prefs.wakeDebug) {
                            ServiceLog.add(String.format(Locale.US, "نتيجة %.2f (الحد %.2f)", score, th))
                            debugToast(score, th)
                        }
                        if (score <= th) {
                            ServiceLog.wakes++
                            wake = true
                        }
                    }
                }
            } catch (e: Exception) {
                ServiceLog.add("خطأ في حلقة الميكروفون: " + (e.message ?: "؟"))
            } finally {
                try {
                    rec.stop()
                } catch (e: Exception) {
                    // تجاهل
                }
                rec.release()
            }
            if (wake && !stopFlag) handleWake()
        }
    }

    private fun debugToast(score: Float, th: Float) {
        val ok = if (score <= th) "✔ تعرّف" else "✘ رفض"
        val msg = String.format(Locale.US, "النتيجة %.2f (الحد %.2f) %s", score, th, ok)
        main.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    /** تُستدعى من خيط الحلقة: تنتظر حتى ينتهي الاستماع للأمر وتنفيذه. */
    private fun handleWake() {
        val latch = CountDownLatch(1)
        main.post { captureCommand { latch.countDown() } }
        try {
            latch.await(60, TimeUnit.SECONDS)
        } catch (e: InterruptedException) {
            // تجاهل
        }
        sleepQuiet(500)
    }

    // ───────────────────────── أدوات مشتركة (خيط الواجهة) ─────────────────────────

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            main.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) {
            // تجاهل
        }
    }

    private fun destroyRecognizer() {
        sessionToken++
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // تجاهل
        }
        recognizer = null
    }

    /** الاستماع لأمر واحد عبر خدمة التعرف (للطريقة المحلية). */
    private fun captureCommand(done: () -> Unit) {
        var finished = false
        val finish = {
            if (!finished) {
                finished = true
                destroyRecognizer()
                updateNotification(null)
                done()
            }
        }
        updateNotification("🎙️ أسمعك… تكلّم الآن")
        beep()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("خدمة التعرف على الصوت غير متوفرة على جهازك.") { finish() }
            return
        }
        val firstTimeout = Runnable { finish() }
        try {
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                }

                override fun onBeginningOfSpeech() {
                }

                override fun onRmsChanged(rmsdB: Float) {
                }

                override fun onBufferReceived(buffer: ByteArray?) {
                }

                override fun onEndOfSpeech() {
                }

                override fun onError(error: Int) {
                    ServiceLog.add("خطأ أثناء الاستماع للأمر: رمز $error")
                    main.removeCallbacks(firstTimeout)
                    finish()
                }

                override fun onResults(results: Bundle?) {
                    main.removeCallbacks(firstTimeout)
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) {
                        finish()
                    } else {
                        ServiceLog.commands++
                        ServiceLog.add("أمر: " + text.take(80))
                        main.postDelayed({ finish() }, 30000)
                        handleText(text) { finish() }
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                }

                override fun onEvent(eventType: Int, params: Bundle?) {
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.speechLang)
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !prefs.allowOnline)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            sr.startListening(i)
            main.postDelayed(firstTimeout, 15000)
        } catch (e: Exception) {
            finish()
        }
    }

    private fun handleText(text: String, done: () -> Unit) {
        var replied = false
        try {
            router.handle(text) { reply ->
                main.post {
                    if (!replied) {
                        replied = true
                        speak(reply) { done() }
                    }
                }
            }
        } catch (e: Exception) {
            speak("حصل خطأ غير متوقع.") { done() }
        }
    }

    private fun speak(text: String, onDone: (() -> Unit)?) {
        val engine = tts
        if (!ttsReady || engine == null) {
            onDone?.invoke()
            return
        }
        val clean = text
            .replace(Regex("https?://\\S+"), " رابط ")
            .replace(Regex("[\\p{So}\\p{Cs}•]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(400)
        if (clean.isEmpty()) {
            onDone?.invoke()
            return
        }
        val id = "u" + System.nanoTime()
        if (onDone != null) ttsCallbacks[id] = onDone
        val r = engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
        if (r != TextToSpeech.SUCCESS) {
            ttsCallbacks.remove(id)?.invoke()
        }
    }

    private fun speak(text: String) {
        speak(text, null)
    }

    private fun finishUtterance(id: String?) {
        if (id == null) return
        main.post { ttsCallbacks.remove(id)?.invoke() }
    }

    // ───────────────────────── Host ─────────────────────────

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun hasLocation(): Boolean =
        hasPerm(Manifest.permission.ACCESS_FINE_LOCATION) || hasPerm(Manifest.permission.ACCESS_COARSE_LOCATION)

    override fun launch(intent: Intent, label: String): Int {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // الإذن «الظهور فوق التطبيقات» يسمح (غالبًا) بفتح التطبيقات من الخلفية.
        if (Settings.canDrawOverlays(this)) {
            return try {
                startActivity(intent)
                Host.LAUNCHED
            } catch (e: Exception) {
                Host.LAUNCH_FAILED
            }
        }
        // وإلا نعرض إشعارًا يضغط عليه المستخدم لإكمال الأمر.
        return try {
            val pi = PendingIntent.getActivity(
                this,
                (System.currentTimeMillis() % 100000).toInt(),
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, CHANNEL_ACTIONS)
                .setSmallIcon(R.drawable.ic_stat_mic)
                .setContentTitle("اضغط لإكمال الأمر")
                .setContentText(label)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(actionNotifId++, n)
            Host.PENDING_TAP
        } catch (e: Exception) {
            Host.LAUNCH_FAILED
        }
    }

    override fun withLocation(cb: (Location?) -> Unit) {
        if (!hasLocation()) {
            cb(null)
            return
        }
        main.post { LocationHelper.getLocation(this, 8000L) { loc -> cb(loc) } }
    }

    override fun triggerSos() {
        speak("جارٍ تفعيل الطوارئ.")
        withLocation { loc ->
            val msg = Sos.buildMessage(loc)
            val contacts = prefs.emergencyContacts
            if (contacts.isEmpty()) {
                speak("لا توجد جهات طوارئ محفوظة. افتح التطبيق وأضفها.")
                launch(Sos.shareIntent(msg), "إرسال رسالة الطوارئ")
            } else if (prefs.autoSendSos && hasPerm(Manifest.permission.SEND_SMS)) {
                confirmSensitive("إرسال رسالة الطوارئ وموقعك إلى ${contacts.size} جهة") {}
                speak("أحتاج تأكيدًا يدويًا من داخل التطبيق قبل إرسال رسالة الطوارئ.")
            } else {
                val r = launch(Sos.composeIntent(contacts, msg), "رسالة الطوارئ جاهزة — اضغط للإرسال")
                if (r == Host.PENDING_TAP) {
                    speak("رسالة الطوارئ جاهزة. اضغط الإشعار لإرسالها.")
                } else {
                    speak("فتحت رسالة الطوارئ.")
                }
            }
        }
    }

    override fun confirmSensitive(summary: String, onConfirmed: () -> Unit) {
        // لا ننفذ حذفًا أو إرسالًا أو تنظيفًا من الخلفية اعتمادًا على تعرف صوتي فقط.
        postProblem("تأكيد مطلوب: $summary — افتح التطبيق واضغط موافقًا للتنفيذ.")
    }
}
